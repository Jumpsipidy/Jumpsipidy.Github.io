// background.js v4.1 PRO — Chrome (Manifest V3)
// 3-Layer Advanced Injection System

// ─── ADVANCED 3-LAYER INJECTION SYSTEM ───
// Layer 1: scripting.executeScript with file (MV3 standard)
// Layer 2: scripting.executeScript with inline function
// Layer 3: tabs.executeScript (deprecated but works as fallback)
async function injectWithFallbacks(tabId) {
  const errors = [];

  // ── Layer 1: scripting API with file ──
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
    console.log('[BG] Layer 1 injection OK');
    return { ok: true, method: 'layer1_scripting_file' };
  } catch(e1) {
    errors.push('L1: ' + e1.message);
    console.warn('[BG] Layer 1 failed:', e1.message);
  }

  // ── Layer 2: scripting API with inline function ──
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        if(window.__elijasGPT_loaded) return 'already_loaded';
        // Signal that we need a reload
        window.__elijasNeedsReload = true;
        return 'needs_file_injection';
      }
    });
    // Try file injection again after short pause
    await new Promise(r => setTimeout(r, 200));
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
    console.log('[BG] Layer 2 injection OK');
    return { ok: true, method: 'layer2_scripting_func' };
  } catch(e2) {
    errors.push('L2: ' + e2.message);
    console.warn('[BG] Layer 2 failed:', e2.message);
  }

  // ── Layer 3: tabs.executeScript (deprecated MV2-style fallback) ──
  try {
    if(chrome.tabs.executeScript) {
      await new Promise((resolve, reject) => {
        chrome.tabs.executeScript(tabId, { file: 'content.js' }, (result) => {
          if(chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(result);
        });
      });
      console.log('[BG] Layer 3 injection OK');
      return { ok: true, method: 'layer3_tabs_deprecated' };
    }
  } catch(e3) {
    errors.push('L3: ' + e3.message);
    console.warn('[BG] Layer 3 failed:', e3.message);
  }

  const errMsg = errors.join(' | ');
  console.error('[BG] All injection layers failed:', errMsg);
  return { error: errMsg, allFailed: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if(message.type === 'CAPTURE_SCREENSHOT_JPEG') {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if(!tabs || !tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: 'jpeg', quality: 97 }, (dataUrl) => {
        if(chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
        else sendResponse({ dataUrl });
      });
    });
    return true;
  }

  if(message.type === 'CAPTURE_SCREENSHOT') {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if(!tabs || !tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: 'png' }, (dataUrl) => {
        if(chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
        else sendResponse({ dataUrl });
      });
    });
    return true;
  }

  if(message.type === 'INJECT_CONTENT') {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, async (tabs) => {
      if(!tabs || !tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      const url = tabs[0].url || '';
      if(url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url === '') {
        sendResponse({ error: 'Cannot inject into: ' + url.substring(0, 40) });
        return;
      }
      const result = await injectWithFallbacks(tabs[0].id);
      sendResponse(result);
    });
    return true;
  }

  if(message.type === 'GET_ORB_STATE') {
    chrome.storage.local.get('elijasOrbDisabled', (r) => {
      sendResponse({ disabled: !!r.elijasOrbDisabled });
    });
    return true;
  }
});
