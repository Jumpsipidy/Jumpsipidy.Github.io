// background.js v4.0 — Firefox version (Sidebar & Screenshot Manager)
// Opens sidebar when toolbar button is clicked
browser.browserAction.onClicked.addListener((tab) => {
  browser.sidebarAction.toggle();
});

// Handle messages from sidebar/popup
browser.runtime.onMessage.addListener((message, sender) => {
  if (message.type === "TOGGLE_SIDEBAR") {
    browser.sidebarAction.toggle();
    return Promise.resolve({ success: true });
  }

  if (message.type === "CAPTURE_SCREENSHOT_JPEG") {
    // Get the active tab in the last focused window (not the sidebar itself)
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
      if (!tabs || tabs.length === 0) {
        return { error: "No active tab found" };
      }
      return browser.tabs.captureVisibleTab(tabs[0].windowId, {
        format: "jpeg",
        quality: 95
      }).then(dataUrl => {
        return { dataUrl };
      }).catch(err => {
        return { error: err.message };
      });
    }).catch(err => {
      return { error: err.message };
    });
  }

  if (message.type === "CAPTURE_SCREENSHOT") {
    // Get the active tab in the last focused window (not the sidebar itself)
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
      if (!tabs || tabs.length === 0) {
        return { error: "No active tab found" };
      }
      return browser.tabs.captureVisibleTab(tabs[0].windowId, {
        format: "png"
      }).then(dataUrl => {
        return { dataUrl };
      }).catch(err => {
        return { error: err.message };
      });
    }).catch(err => {
      return { error: err.message };
    });
  }

  if (message.type === "INJECT_CONTENT") {
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
      if (!tabs || tabs.length === 0) return { error: "No active tab" };
      return browser.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ["content.js"]
      }).then(() => ({ ok: true })).catch(err => ({ error: err.message }));
    });
  }
});
