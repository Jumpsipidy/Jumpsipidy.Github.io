// content.js v4.0 — Firefox version (browser.* API, ElijasGPT V4 Scanner & Action Engine)

let scannedElements = [];
window.elijasAnswered = window.elijasAnswered || new WeakSet();

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function isVisible(el) {
  if(!el) return false;
  const r = el.getBoundingClientRect();
  const s = window.getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0' && r.width > 0 && r.height > 0;
}

function getLabelText(el) {
  if(el.labels && el.labels.length > 0) return el.labels[0].innerText.trim();
  if(el.getAttribute('aria-label')) return el.getAttribute('aria-label');
  const lb = el.getAttribute('aria-labelledby');
  if(lb) { const le = document.getElementById(lb); if(le) return le.innerText.trim(); }
  const pl = el.closest('label');
  if(pl) return pl.innerText.trim();
  if(el.nextSibling?.textContent) return el.nextSibling.textContent.trim();
  if(el.parentElement) return el.parentElement.innerText.trim().substring(0, 100);
  return '';
}

function scanPage() {
  scannedElements = [];
  const seen = new WeakSet();

  function add(el, type, text, extra = {}) {
    if(!el || seen.has(el) || !isVisible(el)) return;
    seen.add(el);
    const rect = el.getBoundingClientRect();
    scannedElements.push({
      index: scannedElements.length,
      type, text: (text||'').trim().substring(0,200),
      rect: { top: Math.round(rect.top), left: Math.round(rect.left), w: Math.round(rect.width), h: Math.round(rect.height) },
      element: el, ...extra
    });
  }

  // --- Radio buttons ---
  document.querySelectorAll('input[type="radio"]').forEach(el => {
    add(el, 'radio', getLabelText(el), { checked: el.checked });
    const c = el.closest('label,[class*="option"],[class*="answer"],[class*="choice"],[class*="variant"]');
    if(c && c !== el) add(c, 'radio_label', c.innerText.trim());
  });

  // --- Checkboxes ---
  document.querySelectorAll('input[type="checkbox"]').forEach(el => {
    add(el, 'checkbox', getLabelText(el), { checked: el.checked });
    const c = el.closest('label,[class*="option"]');
    if(c && c !== el) add(c, 'checkbox_label', c.innerText.trim());
  });

  // --- SEQUENCE NUMBER INPUTS ---
  document.querySelectorAll('input[type="text"],input[type="number"]').forEach(el => {
    if(!isVisible(el)) return;
    const rect = el.getBoundingClientRect();
    const w = rect.width, h = rect.height;
    const isSmall = w < 100 && h < 50;
    let nearby = '';
    const next = el.nextElementSibling;
    const prev = el.previousElementSibling;
    if(next) nearby += next.innerText?.substring(0, 50) || '';
    if(prev) nearby += prev.innerText?.substring(0, 50) || '';
    const hasNearbyText = nearby.length > 3;

    if(isSmall && hasNearbyText) {
      add(el, 'sequence_input', getLabelText(el) || '(order number)', { value: el.value || '' });
    } else if(el.type === 'number' || (el.placeholder && el.placeholder.toLowerCase().includes('number'))) {
      add(el, 'number_input', el.placeholder || el.getAttribute('aria-label') || '');
    } else {
      const parent = el.parentElement?.innerText || '';
      const label = getLabelText(el) || el.placeholder || '';
      const context = (label || parent.substring(0, 100)).trim();
      const isLargeInput = w > 200 || h > 40;
      add(el, isLargeInput ? 'textarea_like' : 'text_input', context);
    }
  });

  // --- Textareas ---
  document.querySelectorAll('textarea').forEach(el => {
    if(!isVisible(el)) return;
    add(el, 'textarea', el.placeholder || el.getAttribute('aria-label') || '(open answer)');
  });

  // --- Selects ---
  document.querySelectorAll('select').forEach(el => {
    if(!isVisible(el)) return;
    add(el, 'select', Array.from(el.options).map(o=>o.text).join(' | '));
  });

  // --- Images ---
  const images = [];
  document.querySelectorAll('img').forEach(img => {
    if(!isVisible(img)) return;
    const imgText = img.alt || img.title || img.getAttribute('data-label') || '[image]';
    add(img, 'image', imgText);
    images.push({ element: img, text: imgText, index: scannedElements.length - 1 });
  });

  document.querySelectorAll('img').forEach(img => {
    if(!isVisible(img)) return;
    let p = img.parentElement;
    let depth = 0;
    while(p && p !== document.body && depth < 5) {
      const s = window.getComputedStyle(p);
      const clickable = p.onclick || p.getAttribute('onclick') || s.cursor === 'pointer' ||
                        p.getAttribute('role') === 'button' || p.tagName === 'A' ||
                        p.getAttribute('draggable') === 'true' ||
                        /match|connect|pair|item|card|photo|image/i.test(p.className || '');
      if(clickable) { add(p, 'image_container', img.alt || img.title || '[photo]'); break; }
      p = p.parentElement; depth++;
    }
  });

  // --- Draggable elements ---
  document.querySelectorAll('[draggable="true"]').forEach(el => {
    add(el, 'draggable', el.innerText?.trim() || el.getAttribute('alt') || el.getAttribute('data-value') || '');
  });

  // --- Drop targets ---
  document.querySelectorAll('[ondrop],[ondragover],[class*="drop-target"],[class*="dropzone"],[class*="droptarget"],[data-droppable="true"]').forEach(el => {
    add(el, 'droptarget', el.innerText?.trim() || '');
  });

  // --- Answer/option elements ---
  const Q = '[class*="answer"],[class*="option"],[class*="choice"],[class*="variant"],[role="radio"],[role="checkbox"],[role="option"],[aria-checked]';
  document.querySelectorAll(Q).forEach(el => {
    if(isVisible(el) && el.innerText?.trim()) {
      const text = el.innerText.trim();
      if(text.length < 150) add(el, 'answer_element', text);
    }
  });

  // --- Text label boxes ---
  document.querySelectorAll('div,span,p,li').forEach(el => {
    if(!isVisible(el) || seen.has(el)) return;
    const s = window.getComputedStyle(el);
    const text = el.innerText?.trim() || '';
    if(!text || text.length > 80 || text.includes('\n')) return;
    const looksLikeLabel =
      s.cursor === 'pointer' ||
      (s.backgroundColor !== 'rgba(0, 0, 0, 0)' && s.backgroundColor !== 'transparent') ||
      (s.border && s.border !== 'none' && s.border !== '0px') ||
      el.getAttribute('onclick') || el.getAttribute('data-id') ||
      /label|tag|match|connect|pair|text-item|text|word/i.test(el.className || '');
    if(looksLikeLabel) add(el, 'label_box', text);
  });

  // --- Sortable items ---
  document.querySelectorAll('[class*="sortable"],[class*="sort-item"],[class*="order-item"],[class*="sequence"],[class*="ranking"]').forEach(el => {
    if(isVisible(el) && el.innerText?.trim()) add(el, 'sortable', el.innerText.trim());
  });

  // --- Buttons ---
  const skipWords = ['submit','next','back','previous','cancel','close','login','sign in','register','continue','skip','save','pirmyn','atgal','uzdaryti'];
  document.querySelectorAll('button,[role="button"]').forEach(el => {
    if(!isVisible(el)) return;
    const t = el.innerText?.trim() || '';
    if(!t || t.length > 80) return;
    if(skipWords.some(w => t.toLowerCase() === w)) return;
    add(el, 'button', t);
  });

  return scannedElements.map(({ element, ...rest }) => rest);
}

// ---- ACTION EXECUTOR ----
async function executeAction(action) {
  try {
    if(action.type === 'drag') {
      const from = scannedElements[action.fromIndex];
      const to   = scannedElements[action.toIndex];
      if(!from || !to) return { success: false, error: `Drag: from=${action.fromIndex} to=${action.toIndex} not found` };
      await simulateDrag(from.element, to.element);
      return { success: true, msg: `Dragged "${from.text}" → "${to.text}"` };
    }

    const entry = scannedElements[action.elementIndex];
    if(!entry) return { success: false, error: `Element index ${action.elementIndex} not found (total: ${scannedElements.length})` };
    const el = entry.element;

    switch(action.type) {
      case 'click':
      case 'check': {
        if(el.type === 'radio' || el.type === 'checkbox') {
          el.checked = true;
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
        el.focus && el.focus();
        el.click();
        el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true }));
        await sleep(250);
        window.elijasAnswered.add(el);
        return { success: true, msg: `Clicked "${entry.text}"` };
      }

      case 'type': {
        el.focus();
        await sleep(120);
        const proto  = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        const setVal = v => setter ? setter.call(el, v) : (el.value = v);
        setVal('');
        el.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(50);
        for(const char of (action.value || '')) {
          el.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
          setVal(el.value + char);
          el.dispatchEvent(new InputEvent('input', { bubbles: true, data: char, inputType: 'insertText' }));
          el.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
          await sleep(30);
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
        window.elijasAnswered.add(el);
        return { success: true, msg: `Typed "${action.value}"` };
      }

      case 'select': {
        const opt = Array.from(el.options || []).find(o =>
          o.text.toLowerCase().includes((action.value||'').toLowerCase()) ||
          o.value.toLowerCase().includes((action.value||'').toLowerCase())
        );
        if(opt) {
          el.value = opt.value;
          el.dispatchEvent(new Event('change', { bubbles: true }));
          window.elijasAnswered.add(el);
          return { success: true, msg: `Selected "${opt.text}"` };
        }
        return { success: false, error: `Option "${action.value}" not found in select` };
      }

      case 'scroll': {
        window.scrollBy({ top: 600, behavior: 'smooth' });
        await sleep(800);
        return { success: true, msg: "Scrolled down" };
      }

      default:
        return { success: false, error: 'Unknown action: ' + action.type };
    }
  } catch(err) {
    return { success: false, error: err.message };
  }
}

async function simulateDrag(fromEl, toEl) {
  const fR = fromEl.getBoundingClientRect();
  const tR = toEl.getBoundingClientRect();
  const sx = fR.left + fR.width/2,  sy = fR.top + fR.height/2;
  const ex = tR.left + tR.width/2,  ey = tR.top + tR.height/2;

  try {
    const dt = new DataTransfer();
    fromEl.dispatchEvent(new DragEvent('dragstart', { bubbles:true, cancelable:true, dataTransfer:dt, clientX:sx, clientY:sy }));
    await sleep(100);
    toEl.dispatchEvent(new DragEvent('dragenter', { bubbles:true, cancelable:true, dataTransfer:dt, clientX:ex, clientY:ey }));
    toEl.dispatchEvent(new DragEvent('dragover',  { bubbles:true, cancelable:true, dataTransfer:dt, clientX:ex, clientY:ey }));
    await sleep(100);
    toEl.dispatchEvent(new DragEvent('drop',      { bubbles:true, cancelable:true, dataTransfer:dt, clientX:ex, clientY:ey }));
    fromEl.dispatchEvent(new DragEvent('dragend',  { bubbles:true, dataTransfer:dt, clientX:ex, clientY:ey }));
  } catch(e) { console.warn('HTML5 drag:', e.message); }

  await sleep(150);

  fromEl.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, clientX:sx, clientY:sy }));
  await sleep(60);
  for(let i = 0; i <= 15; i++) {
    const x = sx + (ex-sx)*(i/15), y = sy + (ey-sy)*(i/15);
    document.dispatchEvent(new MouseEvent('mousemove', { bubbles:true, clientX:x, clientY:y }));
    await sleep(15);
  }
  const dropEl = document.elementFromPoint(ex, ey) || toEl;
  dropEl.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, clientX:ex, clientY:ey }));
  dropEl.dispatchEvent(new MouseEvent('click',   { bubbles:true, clientX:ex, clientY:ey }));
  await sleep(250);
  window.elijasAnswered.add(fromEl);
  window.elijasAnswered.add(toEl);
}

// ---- MESSAGE HANDLER (Firefox uses browser.runtime, Promise-based) ----
browser.runtime.onMessage.addListener((message, sender) => {
  if(message.type === 'PING') {
    return Promise.resolve({ pong: true });
  }

  if(message.type === 'SCAN_PAGE') {
    try {
      const elements = scanPage();
      return Promise.resolve({ elements, title: document.title, url: location.href, count: elements.length });
    } catch(e) {
      return Promise.resolve({ error: e.message, elements: [] });
    }
  }

  if(message.type === 'EXECUTE_ACTIONS') {
    return (async () => {
      const results = [];
      for(const action of (message.actions || [])) {
        const res = await executeAction(action);
        results.push(res);
        await sleep(action.type === 'drag' ? 600 : 300);
      }
      return { results, done: true };
    })();
  }

  if(message.type === 'GET_PAGE_TEXT') {
    return Promise.resolve({ text: document.body?.innerText?.substring(0, 5000) || '' });
  }
});

// --- KEYBOARD SHORTCUT & LAUNCHER WIDGET ---
window.addEventListener('keydown', (e) => {
  if (e.altKey && e.key === '4') {
    e.preventDefault();
    e.stopPropagation();
    sendToggleMessage();
  }
}, true);

function sendToggleMessage() {
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'TOGGLE_SIDEBAR' });
  } else if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
    browser.runtime.sendMessage({ type: 'TOGGLE_SIDEBAR' });
  }
}

function injectLauncher() {
  if (document.getElementById('elijasgpt-floating-trigger')) return;

  const container = document.createElement('div');
  container.id = 'elijasgpt-floating-trigger';
  container.style.position = 'fixed';
  container.style.bottom = '20px';
  container.style.right = '20px';
  container.style.zIndex = '2147483647';
  
  const shadow = container.attachShadow({ mode: 'closed' });
  
  const style = document.createElement('style');
  style.textContent = `
    .launcher {
      width: 46px;
      height: 46px;
      border-radius: 50%;
      background: linear-gradient(135deg, #C8861A, #E8A83A);
      box-shadow: 0 4px 16px rgba(200, 134, 26, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      user-select: none;
      opacity: 0.75;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .launcher:hover {
      transform: scale(1.1) translateY(-2px);
      opacity: 1;
      box-shadow: 0 6px 20px rgba(200, 134, 26, 0.6);
    }
    .launcher:active {
      transform: scale(0.95);
    }
    .icon {
      font-size: 22px;
      color: #1A1814;
      font-weight: bold;
      filter: drop-shadow(0 1px 1px rgba(255,255,255,0.2));
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .tooltip {
      position: absolute;
      bottom: 58px;
      right: 0;
      background: #1C1A14;
      color: #EDEAE3;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 500;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      white-space: nowrap;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      border: 1px solid rgba(247, 245, 240, 0.09);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s ease, transform 0.2s ease;
      transform: translateY(5px);
    }
    .launcher:hover + .tooltip {
      opacity: 1;
      transform: translateY(0);
    }
  `;
  
  const launcher = document.createElement('div');
  launcher.className = 'launcher';
  launcher.innerHTML = '<span class="icon">⚡</span>';
  
  const tooltip = document.createElement('div');
  tooltip.className = 'tooltip';
  tooltip.innerHTML = 'ElijasGPT (Alt+4)';
  
  launcher.addEventListener('click', () => {
    sendToggleMessage();
  });
  
  shadow.appendChild(style);
  shadow.appendChild(launcher);
  shadow.appendChild(tooltip);
  
  document.body.appendChild(container);
}

if (document.body) {
  injectLauncher();
} else {
  document.addEventListener('DOMContentLoaded', injectLauncher);
}
