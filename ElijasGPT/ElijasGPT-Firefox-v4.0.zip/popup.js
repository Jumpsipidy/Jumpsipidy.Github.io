// popup.js v4.0 — Firefox Version (browser.* API, Promise-based, ElijasGPT V4 Engine)

const GEMINI_API_KEY  = "AIzaSyDs761z8dY-JyuQv21TIeadogXyFstPbwk";
const GROQ_API_KEY    = "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";
const MISTRAL_API_KEY = "5wuzyeWmYSgmAX447hJ19IpVN7hEJqEY";

const output       = document.getElementById("output");
const preview      = document.getElementById("preview");
const userPromptEl = document.getElementById("userPrompt");
let isRunning = false, shouldStop = false;

const STORAGE_KEY = "inputFieldValue", ANSWERS_KEY = "autoSolveAnswers", DEBOUNCE_DELAY = 500;
const saveValue   = async v  => { try { await browser.storage.local.set({ [STORAGE_KEY]: v }); } catch(e) {} };
const loadValue   = async () => { try { const r = await browser.storage.local.get(STORAGE_KEY); return r[STORAGE_KEY] ?? ""; } catch(e) { return ""; } };
const saveAnswers = async a  => { try { await browser.storage.local.set({ [ANSWERS_KEY]: a }); } catch(e) {} };
const loadAnswers = async () => { try { const r = await browser.storage.local.get(ANSWERS_KEY); return r[ANSWERS_KEY] ?? []; } catch(e) { return []; } };
const debounce    = (fn, d)  => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), d); }; };
const sleep       = ms       => new Promise(r => setTimeout(r, ms));

function setStatus(t)        { const e = document.getElementById("status");        if(e) e.textContent = t; }
function setStatusSmall(t)   { const e = document.getElementById("status-small");  if(e) e.textContent = t; }
function setActionLog(t)     { const e = document.getElementById("action-log");    if(e) e.textContent = t; }
function showCountdownCard(s){ const e = document.getElementById("countdown-card"); if(e) e.style.display = s ? "block" : "none"; }
function setCountdownDisplay(t, go) {
  const e = document.getElementById("countdown-display");
  if(!e) return; e.textContent = t; e.style.display = "block"; e.className = go ? "go" : "";
}
function setButtons(running) {
  ["autoAnswerBtn","autoSolveBtn","analyzePage","capturePage","clearAnswers"].forEach(id => {
    const b = document.getElementById(id); if(b) b.disabled = running;
  });
  const s = document.getElementById("stopBtn"); if(s) s.disabled = !running;
}

// --- SCREENSHOT RESIZE ---
function resizeDataUrl(dataUrl, maxW = 900, quality = 0.72) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxW / img.width);
      const w = Math.round(img.width  * scale);
      const h = Math.round(img.height * scale);
      const c = document.createElement("canvas");
      c.width = w; c.height = h;
      c.getContext("2d").drawImage(img, 0, 0, w, h);
      resolve(c.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

async function getScreenshot() {
  try {
    const res = await browser.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" });
    if(!res || res.error) return null;
    return res.dataUrl;
  } catch(e) { return null; }
}

// --- CONTENT SCRIPT MESSAGING ---
async function sendToPage(message) {
  const tabs = await browser.tabs.query({ active: true, lastFocusedWindow: true });
  if(!tabs || tabs.length === 0) throw new Error("Aktyvus naršyklės langas nerastas");
  const tabId  = tabs[0].id;
  const tabUrl = tabs[0].url || "";

  if(tabUrl.startsWith("about:") || tabUrl.startsWith("moz-extension://")) {
    throw new Error("Šiame puslapyje plėtinys neveikia. Atidarykite testų puslapį.");
  }

  const alive = await browser.tabs.sendMessage(tabId, { type: "PING" })
    .then(res => res?.pong === true)
    .catch(() => false);

  if(!alive) {
    setStatus("Prijungiamas pagelbininkas į puslapį...");
    try {
      await browser.runtime.sendMessage({ type: "INJECT_CONTENT" });
      await sleep(500);
    } catch(e) {
      throw new Error("Nepavyko prijungti script'o: " + e.message + ". Perkraukite puslapį.");
    }
  }

  return browser.tabs.sendMessage(tabId, message);
}

// --- COUNTDOWN ---
async function runCountdown(seconds) {
  for(let i = seconds; i > 0; i--) {
    if(shouldStop) return false;
    setCountdownDisplay(String(i), false);
    setStatus("Nustatykite klausimą ekrane dabar!");
    await sleep(1000);
  }
  if(shouldStop) return false;
  setCountdownDisplay("Analizuojama...", true);
  setStatus("Daroma ekrano nuotrauka...");
  await sleep(300);
  return true;
}

// --- V4 PROMPTS ---
const SOLVER_PROMPT = `ElijasGPT V4 Quiz & Task Solver. Analyze the screenshot carefully and solve all visible questions/tasks.

Provide clear, actionable, simple Lithuanian explanations for each question. Explain WHAT, WHERE, and HOW.

Format each question systematically:

📌 Klausimas X [Užduoties tipas: Pasirinkimas / Įvestis / Sujungimas / Sudėliojimas / Teisinga-Neteisinga]
• Atsakymas (KĄ): [Tikslus atsakymas]
• Vieta (KUR): [Langelio, pasirinkimo ar lauko vieta ekrane, pvz., 1-as mėlynas langelis dešinėje]
• Veiksmas (KAIP): [Tikslus veiksmas, pvz., Pasirink B / Įrašyk: Vilnius / Nutempk "Fotosintezė" į 1-ą langelį dešinėje]

Task types guide:
- Multiple choice: Pasirink A/B/C/D ir nurodyk pasirinkimo vietą
- Matching / Drag-and-Drop: Nurodyk KĄ elementą nutempti / sujungti, KUR atitinkamą langelį padėti
- Text input: Nurodyk tekstą ir KURĮ įvesties laukelį įrašyti
- Sequence / Ordering: Nurodyk pilną teisingą tvarką ir kokį skaičių/elementą kur dėti
- True / False: Nurodyk Atsakymą (Teisinga / Neteisinga) ir kurį mygtuką paspausti

Language: Output in natural, simple Lithuanian (or English if the quiz is in English).
Do NOT produce generic vague text like "1 - answer". Always state WHAT, WHERE, and HOW.
Reply NOQUESTIONS only if screen is completely blank or login page.`;

function buildAutoAnswerPrompt(elements, pageTitle) {
  const useful = elements.filter(el =>
    ['radio','radio_label','checkbox','checkbox_label','text_input','number_input','sequence_input',
     'select','textarea','textarea_like',
     'draggable','droptarget','answer_element','image','image_container',
     'label_box','sortable','button'].includes(el.type)
  ).slice(0, 60);

  const elemList = useful.map(el => {
    let line = `[${el.index}] ${el.type}: "${el.text}"`;
    if(el.rect)  line += ` @(${el.rect.top},${el.rect.left},w:${el.rect.w},h:${el.rect.h})`;
    if(el.value !== undefined) line += ` value="${el.value}"`;
    return line;
  }).join('\n');

  return `ElijasGPT V4 Auto Quiz Solver. Page: "${pageTitle}"

PAGE ELEMENTS (index number = use in actions):
${elemList}

IMPORTANT QUESTION TYPE PATTERNS & HOW TO SOLVE:

1) MULTIPLE CHOICE / TRUE-FALSE / SINGLE SELECT:
   → Click the correct radio_label or answer_element
   → Action: {"type":"click","elementIndex":N}

2) FILL IN THE BLANK (single word):
   → Type the missing word into text_input
   → Action: {"type":"type","elementIndex":N,"value":"word"}

3) OPEN TEXT ANSWER (full sentence/paragraph):
   → Find textarea or textarea_like element
   → Type the complete answer
   → Action: {"type":"type","elementIndex":N,"value":"full sentence"}

4) CHRONOLOGICAL / SEQUENCE ORDERING:
   → Assign correct numbers (1,2,3...) to sequence_input elements
   → Actions: {"type":"click","elementIndex":N}, {"type":"type","elementIndex":N,"value":"1"}

5) PHOTO-TO-TEXT MATCHING:
   → Click text label first, then matching image container
   → Two separate click actions per pair

6) DRAG-AND-DROP CONNECT:
   → Action: {"type":"drag","fromIndex":N,"toIndex":M}

7) DROPDOWN SELECT:
   → Action: {"type":"select","elementIndex":N,"value":"option text"}

RETURN ONLY VALID JSON.
Format:
{
  "questionType": "multiple_choice|fill_in|open_text|sequence|photo_match|connect|drag_drop|dropdown|true_false|none",
  "answer": "Clear Lithuanian description of WHAT and WHERE",
  "actions": [
    {"type":"click","elementIndex":5,"reason":"Pasirinkti variantą B"},
    {"type":"type","elementIndex":10,"value":"word"}
  ]
}`;
}

// --- API WRAPPERS ---
async function askGroq(screenshotDataUrl, prompt, systemMsg) {
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + GROQ_API_KEY },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [
          { role: "system", content: systemMsg || "You are ElijasGPT V4 quiz solver. Return structured output." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: screenshotDataUrl } }
          ]}
        ],
        temperature: 0.1, max_tokens: 800
      })
    });
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || body?.error?.code || res.statusText;
      console.warn(`Groq ${res.status}: ${reason}`);
      setStatus(`Groq klaida (${res.status}) → bandoma Mistral...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Groq:", e.message); return null; }
}

async function askMistral(screenshotDataUrl, prompt, systemMsg) {
  try {
    const res = await fetch("https://api.mistral.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + MISTRAL_API_KEY },
      body: JSON.stringify({
        model: "mistral-medium-latest",
        messages: [
          { role: "system", content: systemMsg || "You are ElijasGPT V4 quiz solver. Return structured output." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: screenshotDataUrl } }
          ]}
        ],
        temperature: 0.1, max_tokens: 800
      })
    });
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || body?.error?.code || res.statusText;
      console.warn(`Mistral ${res.status}: ${reason}`);
      setStatus(`Mistral klaida (${res.status}) → bandoma Gemini...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Mistral:", e.message); return null; }
}

async function askGemini(screenshotDataUrl, prompt) {
  try {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + GEMINI_API_KEY,
      { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [
            { text: prompt },
            { inlineData: { mimeType: "image/jpeg", data: screenshotDataUrl.split(",")[1] } }
          ]}],
          generationConfig: { temperature: 0.1, maxOutputTokens: 800 }
        })
      }
    );
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || res.statusText;
      console.warn(`Gemini ${res.status}: ${reason}`);
      setStatus(`Gemini klaida (${res.status})`);
      return null;
    }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? null;
  } catch(e) { console.warn("Gemini:", e.message); return null; }
}

function parseAIJson(text) {
  if(!text) return null;
  try { return JSON.parse(text.trim()); } catch(e) {}
  const m = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if(m) { try { return JSON.parse(m[1].trim()); } catch(e) {} }
  const s = text.indexOf('{'), en = text.lastIndexOf('}');
  if(s !== -1 && en !== -1) { try { return JSON.parse(text.substring(s, en+1)); } catch(e) {} }
  return null;
}

async function askAIForActions(screenshot, elements, pageTitle) {
  const prompt = buildAutoAnswerPrompt(elements, pageTitle);
  const sc = await resizeDataUrl(screenshot);

  setStatus("Groq analizuoja...");
  const r = await askGroq(sc, prompt, "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON.");
  if(r) { const p = parseAIJson(r); if(p) return p; }

  setStatus("Mistral analizuoja...");
  const m = await askMistral(sc, prompt, "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON.");
  if(m) { const p = parseAIJson(m); if(p) return p; }

  setStatus("Gemini analizuoja...");
  const g = await askGemini(sc, prompt);
  if(g) { const p = parseAIJson(g); if(p) return p; }

  return null;
}

async function askAISolve(screenshot) {
  const sc  = await resizeDataUrl(screenshot);
  const sys = "You are ElijasGPT V4. State WHAT, WHERE and HOW for every task in natural simple Lithuanian.";

  setStatus("Groq mąsto...");
  const r = await askGroq(sc, SOLVER_PROMPT, sys);
  if(r) return { text: r, source: "Groq" };

  setStatus("Mistral mąsto...");
  const m = await askMistral(sc, SOLVER_PROMPT, sys);
  if(m) return { text: m, source: "Mistral" };

  setStatus("Gemini mąsto...");
  const g = await askGemini(sc, SOLVER_PROMPT);
  if(g) return { text: g, source: "Gemini" };

  return null;
}

// --- V4 OUTPUT RENDERER ---
function renderV4FormattedAnswers(answersArray) {
  if(!output) return;
  output.innerHTML = "";

  if(!answersArray || answersArray.length === 0) {
    output.textContent = "Nėra gautų rezultatų.";
    return;
  }

  answersArray.forEach(item => {
    const card = document.createElement("div");
    card.className = "q-block";
    
    const text = item.text || item;
    const lines = text.split("\n").filter(l => l.trim().length > 0);
    
    let html = "";
    lines.forEach(line => {
      if(line.startsWith("📌") || line.startsWith("[Q")) {
        html += `<div class="q-title"><span>${line}</span></div>`;
      } else if(line.includes("Atsakymas") || line.includes("(KĄ)")) {
        html += `<div class="q-row q-what">🎯 <strong>${line}</strong></div>`;
      } else if(line.includes("Vieta") || line.includes("Kur") || line.includes("(KUR)")) {
        html += `<div class="q-row q-where">📍 <strong>${line}</strong></div>`;
      } else if(line.includes("Veiksmas") || line.includes("(KAIP)")) {
        html += `<div class="q-row q-how">⚡ <strong>${line}</strong></div>`;
      } else {
        html += `<div class="q-row">${line}</div>`;
      }
    });

    card.innerHTML = html;
    output.appendChild(card);
  });
}

// --- MODAL HANDLING ---
function showAlphaWarning() {
  return new Promise(resolve => {
    const modal = document.getElementById("alpha-warning-modal");
    if(!modal) { resolve(true); return; }
    modal.style.display = "flex";

    const continueBtn = document.getElementById("alpha-continue-btn");
    const cancelBtn   = document.getElementById("alpha-cancel-btn");

    const cleanup = () => {
      continueBtn?.removeEventListener("click", onContinue);
      cancelBtn?.removeEventListener("click", onCancel);
      modal.style.display = "none";
    };
    const onContinue = () => { cleanup(); resolve(true); };
    const onCancel   = () => { cleanup(); resolve(false); };

    continueBtn?.addEventListener("click", onContinue);
    cancelBtn?.addEventListener("click", onCancel);
  });
}

// --- AUTO-ANSWER ---
async function autoAnswer() {
  const proceed = await showAlphaWarning();
  if(!proceed) return;

  if(isRunning) return;
  isRunning = true; shouldStop = false;
  setButtons(true); showCountdownCard(true);
  output.textContent = "Pradedamas V4 AUTO-ANSWER..."; setActionLog("");

  let totalDone = 0, round = 0, noQStreak = 0, failStreak = 0;
  const MAX = 100, MAX_NO_Q = 3, MAX_FAIL = 3;

  while(round < MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    setCountdownDisplay("Nuskaitoma...", true);
    setStatus("Nuskaitomi puslapio elementai...");
    let pageData;
    try { pageData = await sendToPage({ type: "SCAN_PAGE" }); }
    catch(e) {
      setStatus("Skenavimas nepavyko: " + e.message);
      setCountdownDisplay("Klaida", false); failStreak++;
      if(failStreak >= MAX_FAIL) break;
      round--; await sleep(1500); continue;
    }

    const elements = pageData?.elements || [];
    setActionLog("Rasta elementų: " + elements.length);

    const screenshot = await getScreenshot();
    if(!screenshot) { setStatus("Nuotrauka nepavyko."); failStreak++; if(failStreak >= MAX_FAIL) break; round--; continue; }

    setCountdownDisplay("AI mąsto...", true);
    const aiResult = await askAIForActions(screenshot, elements, pageData.title || "");

    if(!aiResult) {
      failStreak++;
      setCountdownDisplay("AI klaida", false);
      setStatus("AI neatsakė (" + failStreak + "/" + MAX_FAIL + "). Patikrinkite internetą.");
      if(failStreak >= MAX_FAIL) { setStatus("Sustabdyta — AI neatsako."); break; }
      round--; await sleep(1500); continue;
    }
    failStreak = 0;

    if(aiResult.questionType === "none" || !aiResult.actions || aiResult.actions.length === 0) {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatus("Klausimų nerasta (" + noQStreak + "/" + MAX_NO_Q + "). Nustatykite klausimą ekrane.");
      await sleep(1000);
      if(noQStreak >= MAX_NO_Q) { setStatus("Baigta — daugiau klausimų nerasta."); setCountdownDisplay("Baigta!", true); break; }
      continue;
    }
    noQStreak = 0;

    setCountdownDisplay("Vykdoma!", true);
    setStatus("Atsakymas: " + aiResult.answer + " [" + aiResult.questionType + "]");
    setActionLog("Vykdomi " + aiResult.actions.length + " veiksmas(-ai)...");

    let execResult;
    try { execResult = await sendToPage({ type: "EXECUTE_ACTIONS", actions: aiResult.actions }); }
    catch(e) { setStatus("Vykdymas nepavyko: " + e.message); await sleep(1500); continue; }

    const results = execResult?.results || [];
    const passed  = results.filter(r => r.success).length;
    totalDone++;

    const log = results.map((r,i) => (r.success ? "✓" : "✗") + " " + (r.msg || r.error || "veiksmas " + (i+1))).join("\n");
    const summaryText = `📌 K${round} [${aiResult.questionType}]\n• Atsakymas (KĄ): ${aiResult.answer}\n• Veiksmas (KAIP): Atlikta ${passed}/${results.length} veiksmų\n${log}`;

    const currentCards = Array.from(output.querySelectorAll(".q-block")).map(c => ({ text: c.innerText }));
    currentCards.unshift({ text: summaryText });
    renderV4FormattedAnswers(currentCards);

    setStatus("✓ K" + round + " atlikta! " + passed + "/" + results.length + " veiksmai. Viso: " + totalDone);
    setCountdownDisplay("Atlikta!", true);
    setActionLog(log.split('\n')[0] || "");
    await sleep(2000);
  }

  if(shouldStop) { setStatus("Sustabdyta. Atlikta: " + totalDone); setCountdownDisplay("Sustabdyta", false); }
  await sleep(2000);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Baigta: " + totalDone + " atsakyta.");
  isRunning = false;
}

// --- AUTO-SOLVE ---
async function autoSolvePage() {
  if(isRunning) return;
  isRunning = true; shouldStop = false;
  setButtons(true); showCountdownCard(true);
  let allAnswers = [];
  await saveAnswers(allAnswers);
  output.textContent = "Pradedamas V4 AUTO-SOLVE...";
  let round = 0, noQStreak = 0, failStreak = 0;
  const MAX = 100, MAX_NO_Q = 3, MAX_FAIL = 4;

  while(round < MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    const screenshot = await getScreenshot();
    if(!screenshot) { failStreak++; setStatus("Ekrano nuotrauka nepavyko."); if(failStreak >= MAX_FAIL) break; round--; continue; }

    setCountdownDisplay("Analizuojama...", true);
    const result = await askAISolve(screenshot);

    if(!result) {
      failStreak++;
      setStatus("Visos 3 API nepavyko (" + failStreak + "/" + MAX_FAIL + ")");
      if(failStreak >= MAX_FAIL) break;
      round--; await sleep(1500); continue;
    }
    failStreak = 0;

    const trimmed = result.text.trim();
    const blank   = trimmed === "" || trimmed.toUpperCase() === "NOQUESTIONS";

    if(!blank) {
      noQStreak = 0;
      allAnswers.push({ text: `[Klausimas ${round} — ${result.source}]\n${trimmed}` });
      renderV4FormattedAnswers(allAnswers);
      await saveAnswers(allAnswers);
      setStatus("✓ Klausimas " + round + " išanalizuotas (" + result.source + ")! Viso: " + allAnswers.length);
      setCountdownDisplay("Gauta!", true);
      await sleep(1500);
    } else {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatus("Klausimas nerastas (" + noQStreak + "/" + MAX_NO_Q + ").");
      await sleep(1000);
      if(noQStreak >= MAX_NO_Q) { setStatus("Baigta."); setCountdownDisplay("Baigta!", true); break; }
    }
  }

  if(shouldStop) { setStatus("Sustabdyta. Išsaugota: " + allAnswers.length); setCountdownDisplay("Sustabdyta", false); }
  await sleep(2500);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Auto-solve: " + allAnswers.length + " atsakymai.");
  isRunning = false;
}

// --- ANALYZE PAGE ---
async function analyzePage() {
  const prompt = userPromptEl.value.trim() || "Išanalizuok šį puslapį ir paaiškink užduotį (KĄ, KUR, KAIP).";
  setStatusSmall("Analizuojama..."); output.textContent = "Analizuojama...";
  const raw = await getScreenshot();
  if(!raw) { setStatusSmall("Nuotrauka nepavyko."); output.textContent = "Nuotrauka nepavyko."; return; }
  const sc  = await resizeDataUrl(raw);
  const sys = "Paaiškink užduotį aiškiai ir suprantamai lietuviškai.";
  let text = await askGroq(sc, prompt, sys), src = "Groq";
  if(!text) { text = await askMistral(sc, prompt, sys); src = "Mistral"; }
  if(!text) { text = await askGemini(sc, prompt); src = "Gemini"; }
  if(text) {
    renderV4FormattedAnswers([{ text: `[Analizė — ${src}]\n${text}` }]);
    setStatusSmall("Atlikta — " + src + ".");
  } else { output.textContent = "Visos 3 API nepavyko."; setStatusSmall("Klaida."); }
}

// --- EVENTS ---
document.getElementById("autoAnswerBtn").addEventListener("click", autoAnswer);
document.getElementById("autoSolveBtn").addEventListener("click", autoSolvePage);
document.getElementById("stopBtn").addEventListener("click", () => { shouldStop = true; setStatus("Stabdoma..."); });
document.getElementById("analyzePage").addEventListener("click", analyzePage);
document.getElementById("capturePage").addEventListener("click", async () => {
  setStatusSmall("Daria nuotrauką...");
  const s = await getScreenshot();
  if(s) { preview.src = s; preview.style.display = "block"; setStatusSmall("Atlikta."); }
  else setStatusSmall("Klaida.");
});
document.getElementById("clearAnswers").addEventListener("click", async () => {
  await browser.storage.local.remove(ANSWERS_KEY);
  output.textContent = "Nėra gautų rezultatų."; setStatusSmall("Išvalyta.");
});
document.querySelectorAll(".chip").forEach(chip => {
  chip.addEventListener("click", () => { userPromptEl.value = chip.getAttribute("data-prompt"); });
});

const copyBtn = document.getElementById("copyOutputBtn");
if(copyBtn) {
  copyBtn.addEventListener("click", () => {
    const textToCopy = output.innerText || output.textContent;
    if(textToCopy) {
      navigator.clipboard.writeText(textToCopy).then(() => {
        copyBtn.textContent = "Kopijuota! ✓";
        setTimeout(() => copyBtn.textContent = "Kopijuoti", 2000);
      });
    }
  });
}

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  const box = document.getElementById("answer-box");
  if(box) {
    box.value = await loadValue();
    box.addEventListener("input", debounce(async e => { await saveValue(e.target.value); }, DEBOUNCE_DELAY));
  }
  const saved = await loadAnswers();
  if(saved.length > 0) {
    renderV4FormattedAnswers(saved);
    setStatusSmall("Užkrauta " + saved.length + " išsaugotų.");
  }
});
