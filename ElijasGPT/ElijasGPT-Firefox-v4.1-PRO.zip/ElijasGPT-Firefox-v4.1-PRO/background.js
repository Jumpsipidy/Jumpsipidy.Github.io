// background.js v4.1 PRO — Firefox (Manifest V2)
// 3-Layer Advanced Injection System

browser.browserAction.onClicked.addListener(() => {
  browser.sidebarAction.toggle();
});

// ─── ADVANCED 3-LAYER INJECTION SYSTEM ───
// Layer 1: tabs.executeScript with file (standard MV2 method)
// Layer 2: tabs.executeScript with inline minimal bootstrap code
// Layer 3: Scripting API fallback (for newer Firefox versions that support it)
async function injectWithFallbacks(tabId, tabUrl) {
  const errors = [];

  // ── Layer 1: Standard file injection ──
  try {
    await browser.tabs.executeScript(tabId, {
      file: 'content.js',
      runAt: 'document_idle'
    });
    console.log('[BG] Layer 1 injection OK');
    return { ok: true, method: 'layer1_file' };
  } catch(e1) {
    errors.push('L1: ' + e1.message);
    console.warn('[BG] Layer 1 failed:', e1.message);
  }

  // ── Layer 2: Inline minimal bootstrap that re-loads content.js ──
  try {
    await browser.tabs.executeScript(tabId, {
      code: `
        (function() {
          if(window.__elijasGPT_loaded) {
            console.log('[ElijasGPT] Already loaded (Layer 2 check)');
            return;
          }
          // Create a script tag to load content.js from extension
          var s = document.createElement('script');
          s.src = browser.runtime.getURL('content.js');
          s.onload = function() { console.log('[ElijasGPT] Loaded via script tag'); };
          s.onerror = function() { console.error('[ElijasGPT] Script tag load failed'); };
          (document.head || document.documentElement).appendChild(s);
        })();
      `,
      runAt: 'document_idle'
    });
    console.log('[BG] Layer 2 injection OK');
    return { ok: true, method: 'layer2_inline' };
  } catch(e2) {
    errors.push('L2: ' + e2.message);
    console.warn('[BG] Layer 2 failed:', e2.message);
  }

  // ── Layer 3: scripting.executeScript (newer Firefox 93+ API) ──
  try {
    if(browser.scripting && browser.scripting.executeScript) {
      await browser.scripting.executeScript({
        target: { tabId },
        files: ['content.js']
      });
      console.log('[BG] Layer 3 injection OK');
      return { ok: true, method: 'layer3_scripting' };
    }
  } catch(e3) {
    errors.push('L3: ' + e3.message);
    console.warn('[BG] Layer 3 failed:', e3.message);
  }

  // ── All layers failed ──
  const errMsg = errors.join(' | ');
  console.error('[BG] All injection layers failed:', errMsg);
  return { error: errMsg, allFailed: true };
}

browser.runtime.onMessage.addListener((message, sender) => {

  if(message.type === 'TOGGLE_SIDEBAR') {
    browser.sidebarAction.toggle();
    return Promise.resolve({ success: true });
  }

  if(message.type === 'CAPTURE_SCREENSHOT_JPEG') {
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
      if(!tabs || !tabs[0]) return { error: 'No active tab' };
      return browser.tabs.captureVisibleTab(tabs[0].windowId, { format: 'jpeg', quality: 97 })
        .then(dataUrl => ({ dataUrl }))
        .catch(err => ({ error: err.message }));
    }).catch(err => ({ error: err.message }));
  }

  if(message.type === 'CAPTURE_SCREENSHOT') {
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
      if(!tabs || !tabs[0]) return { error: 'No active tab' };
      return browser.tabs.captureVisibleTab(tabs[0].windowId, { format: 'png' })
        .then(dataUrl => ({ dataUrl }))
        .catch(err => ({ error: err.message }));
    }).catch(err => ({ error: err.message }));
  }

  if(message.type === 'INJECT_CONTENT') {
    return browser.tabs.query({ active: true, lastFocusedWindow: true }).then(async tabs => {
      if(!tabs || !tabs[0]) return { error: 'No active tab' };
      const tab = tabs[0];
      const url = tab.url || '';

      // Block truly un-injectable pages
      if(url.startsWith('about:') || url.startsWith('moz-extension://') || url === '') {
        return { error: 'Cannot inject into this page type: ' + url.substring(0, 50) };
      }

      return await injectWithFallbacks(tab.id, url);
    });
  }

  if(message.type === 'GET_ORB_STATE') {
    return browser.storage.local.get('elijasOrbDisabled').then(r => ({ disabled: !!r.elijasOrbDisabled }));
  }
});
