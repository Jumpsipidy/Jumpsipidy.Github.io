// content.js v4.1 PRO — ElijasGPT — Firefox + Chrome dual compatible

// ─── Guard: don't load twice ───
if(window.__elijasGPT_loaded) {
  // Already loaded, just respond to any new PINGs
} else {
window.__elijasGPT_loaded = true;

let scannedElements = [];
window.elijasAnswered = window.elijasAnswered || new WeakSet();

const _isFirefox = typeof browser !== 'undefined' && browser.runtime;
const _rt  = _isFirefox ? browser.runtime : (typeof chrome !== 'undefined' ? chrome.runtime : null);
const _st  = _isFirefox ? browser.storage : (typeof chrome !== 'undefined' ? chrome.storage : null);
const _tabs = _isFirefox ? browser.tabs   : (typeof chrome !== 'undefined' ? chrome.tabs   : null);

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function isVisible(el) {
  if(!el) return false;
  try {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity) > 0.1 && r.width > 0 && r.height > 0;
  } catch(e) { return false; }
}

function getLabelText(el) {
  try {
    if(el.labels && el.labels.length > 0) return el.labels[0].innerText.trim();
    if(el.getAttribute('aria-label')) return el.getAttribute('aria-label');
    const lb = el.getAttribute('aria-labelledby');
    if(lb) { const le = document.getElementById(lb); if(le) return le.innerText.trim(); }
    const pl = el.closest('label');
    if(pl) return pl.innerText.trim();
    if(el.nextSibling?.textContent?.trim()) return el.nextSibling.textContent.trim();
    if(el.parentElement) return el.parentElement.innerText.trim().substring(0, 100);
  } catch(e) {}
  return '';
}

// ─── PAGE SCANNER ───
function scanPage() {
  scannedElements = [];
  const seen = new WeakSet();

  function add(el, type, text, extra = {}) {
    if(!el || seen.has(el) || !isVisible(el)) return;
    seen.add(el);
    try {
      const rect = el.getBoundingClientRect();
      scannedElements.push({
        index: scannedElements.length,
        type, text: (text || '').trim().substring(0, 200),
        rect: { top: Math.round(rect.top), left: Math.round(rect.left), w: Math.round(rect.width), h: Math.round(rect.height) },
        element: el, ...extra
      });
    } catch(e) {}
  }

  // Radio buttons
  document.querySelectorAll('input[type="radio"]').forEach(el => {
    add(el, 'radio', getLabelText(el), { checked: el.checked });
    const c = el.closest('label,[class*="option"],[class*="answer"],[class*="choice"],[class*="variant"]');
    if(c && c !== el) add(c, 'radio_label', c.innerText.trim());
  });

  // Checkboxes
  document.querySelectorAll('input[type="checkbox"]').forEach(el => {
    add(el, 'checkbox', getLabelText(el), { checked: el.checked });
    const c = el.closest('label,[class*="option"]');
    if(c && c !== el) add(c, 'checkbox_label', c.innerText.trim());
  });

  // Native <select> dropdowns
  document.querySelectorAll('select').forEach(el => {
    if(!isVisible(el)) return;
    const opts = Array.from(el.options).map(o => o.text.trim()).filter(t => t).join(' | ');
    const label = getLabelText(el) || el.getAttribute('aria-label') || '';
    const currentVal = el.options[el.selectedIndex]?.text?.trim() || '';
    add(el, 'select', `${label} [OPTIONS: ${opts}]`, { value: currentVal });
  });

  // Text / number inputs
  document.querySelectorAll('input[type="text"],input[type="number"],input:not([type])').forEach(el => {
    if(!isVisible(el)) return;
    const rect = el.getBoundingClientRect();
    const label = getLabelText(el) || el.placeholder || '';
    if(el.type === 'number') {
      add(el, 'number_input', label);
    } else {
      add(el, rect.width > 150 ? 'textarea_like' : 'text_input', label.substring(0, 100));
    }
  });

  // Textareas
  document.querySelectorAll('textarea,[contenteditable="true"]').forEach(el => {
    add(el, 'textarea', getLabelText(el) || el.placeholder || el.getAttribute('aria-label') || '',
      { value: (el.value || el.innerText || '').trim().substring(0, 100) });
  });

  // Drag items
  document.querySelectorAll('[draggable="true"],[class*="draggable"],[class*="drag-item"],[class*="word-item"],[class*="token"],[class*="chip"]').forEach(el => {
    const t = el.innerText?.trim() || '';
    if(t && t.length < 120) add(el, 'draggable', t);
  });

  // Drop targets
  document.querySelectorAll('[class*="drop"],[class*="target"],[class*="dropzone"],[class*="gap"],[class*="blank"],[class*="slot"],[class*="placeholder"]').forEach(el => {
    const t = el.innerText?.trim() || el.getAttribute('aria-label') || '';
    add(el, 'droptarget', t.substring(0, 100));
  });

  // Answer elements (custom clickable options)
  document.querySelectorAll('[class*="answer"],[class*="choice"],[class*="option"],[class*="variant"],[class*="item-text"],[role="radio"],[role="option"],[role="checkbox"]').forEach(el => {
    const t = el.innerText?.trim() || '';
    if(t && t.length < 200) add(el, 'answer_element', t);
  });

  // Images
  document.querySelectorAll('img[alt],[class*="image-option"],[class*="img-answer"]').forEach(el => {
    add(el, 'image', el.getAttribute('alt') || 'image');
  });

  // Sortable
  document.querySelectorAll('[class*="sortable"],[class*="sort-item"],[class*="order-item"],[class*="sequence"],[class*="ranking"]').forEach(el => {
    if(isVisible(el) && el.innerText?.trim()) add(el, 'sortable', el.innerText.trim());
  });

  // Clickable spans/divs
  const skipWords = ['submit','next','back','previous','cancel','close','login','register','continue','skip','save','pirmyn','atgal','uzdaryti'];
  document.querySelectorAll('button,[role="button"]').forEach(el => {
    if(!isVisible(el)) return;
    const t = el.innerText?.trim() || '';
    if(!t || t.length > 80) return;
    if(skipWords.some(w => t.toLowerCase() === w)) return;
    add(el, 'button', t);
  });

  return scannedElements.map(({ element, ...rest }) => rest);
}

// ─── ACTION EXECUTOR ───
async function executeAction(action) {
  try {
    // DRAG
    if(action.type === 'drag') {
      const from = scannedElements[action.fromIndex];
      const to   = scannedElements[action.toIndex];
      if(!from || !to) return { success: false, error: `Drag: from=[${action.fromIndex}] to=[${action.toIndex}] not found. Total: ${scannedElements.length}` };
      await simulateDrag(from.element, to.element);
      return { success: true, msg: `Dragged "${from.text}" → "${to.text}"` };
    }

    const entry = scannedElements[action.elementIndex];
    if(!entry) return { success: false, error: `Element [${action.elementIndex}] not found. Total: ${scannedElements.length}` };
    const el = entry.element;

    if(!document.contains(el)) {
      return { success: false, error: `Element [${action.elementIndex}] "${entry.text.substring(0,40)}" no longer in DOM. Page may have changed.` };
    }

    // Auto-convert: AI sends click on <select> → convert to select
    if(action.type === 'click' && entry.type === 'select') {
      action.type = 'select';
    }

    const simulateHumanClick = async (target) => {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(100);
      target.dispatchEvent(new PointerEvent('pointerover', { bubbles: true, cancelable: true, isPrimary: true }));
      target.dispatchEvent(new PointerEvent('pointerenter', { bubbles: true, cancelable: true, isPrimary: true }));
      target.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
      target.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }));
      await sleep(50);
      target.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, isPrimary: true }));
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      target.focus && target.focus();
      await sleep(50);
      target.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, isPrimary: true }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
      target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      target.click && target.click();
      await sleep(50);
    };

    switch(action.type) {

      case 'click':
      case 'check': {
        if(el.type === 'radio' || el.type === 'checkbox') {
          el.checked = true;
          el.dispatchEvent(new Event('change', { bubbles: true }));
          el.dispatchEvent(new Event('input', { bubbles: true }));
        }
        await simulateHumanClick(el);
        window.elijasAnswered.add(el);
        return { success: true, msg: `Clicked "${entry.text.substring(0,40)}"` };
      }

      case 'type': {
        await simulateHumanClick(el);
        // React-compatible value setting
        const proto  = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        const setVal = v => setter ? setter.call(el, v) : (el.value = v);
        setVal('');
        el.dispatchEvent(new Event('input', { bubbles: true }));
        await sleep(40);
        for(const char of (action.value || '')) {
          el.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
          setVal(el.value + char);
          el.dispatchEvent(new InputEvent('input', { bubbles: true, data: char, inputType: 'insertText' }));
          el.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
          await sleep(20);
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
        window.elijasAnswered.add(el);
        return { success: true, msg: `Typed "${(action.value || '').substring(0, 40)}"` };
      }

      case 'select': {
        const val = (action.value || '').toLowerCase().trim();

        if(el.tagName === 'SELECT') {
          // Native <select>
          const opt = Array.from(el.options).find(o =>
            o.text.trim().toLowerCase() === val ||
            o.text.trim().toLowerCase().includes(val) ||
            o.value.toLowerCase() === val
          );
          if(opt) {
            el.focus();
            el.value = opt.value;
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('input',  { bubbles: true }));
            window.elijasAnswered.add(el);
            return { success: true, msg: `Selected "${opt.text.trim()}" in "${entry.text.substring(0,40)}"` };
          }
          const available = Array.from(el.options).map(o => `"${o.text.trim()}"`).join(', ');
          return { success: false, error: `Option "${action.value}" not found in native select. Available: ${available}` };
        }

        // Custom dropdown (React/Vue/Angular)
        await simulateHumanClick(el);
        await sleep(400); // Wait for dropdown to open

        const allOpts = document.querySelectorAll('li,option,[role="option"],[role="listitem"],[class*="option"],[class*="menu-item"],[class*="dropdown-item"]');
        const match = Array.from(allOpts).find(o => {
          if(!isVisible(o)) return false;
          const t = (o.innerText || o.textContent || '').toLowerCase().trim();
          return t === val || t.includes(val);
        });

        if(match) {
          await simulateHumanClick(match);
          return { success: true, msg: `Clicked custom dropdown option "${match.innerText?.trim()}"` };
        }
        return { success: false, error: `Custom option "${action.value}" not found. Ensure it exactly matches text on screen.` };
      }

      case 'scroll': {
        window.scrollBy({ top: 700, behavior: 'smooth' });
        await sleep(800);
        return { success: true, msg: 'Scrolled down 700px' };
      }

      default:
        return { success: false, error: `Unknown action type: ${action.type}` };
    }

  } catch(e) {
    return { success: false, error: 'Exception: ' + e.message };
  }
}

// ─── DRAG & DROP SIMULATOR ───
async function simulateDrag(fromEl, toEl) {
  fromEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await sleep(150);
  
  const f = fromEl.getBoundingClientRect();
  const t = toEl.getBoundingClientRect();
  const fx = f.left + f.width/2;  const fy = f.top + f.height/2;
  const tx = t.left + t.width/2;  const ty = t.top + t.height/2;

  const dataTransfer = new DataTransfer();
  
  fromEl.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: fx, clientY: fy }));
  fromEl.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: fx, clientY: fy }));
  await sleep(50);
  fromEl.dispatchEvent(new DragEvent('dragstart', { bubbles: true, clientX: fx, clientY: fy, dataTransfer }));
  await sleep(50);
  fromEl.dispatchEvent(new DragEvent('drag', { bubbles: true, clientX: fx, clientY: fy, dataTransfer }));
  await sleep(50);

  toEl.dispatchEvent(new DragEvent('dragenter', { bubbles: true, clientX: tx, clientY: ty, dataTransfer }));
  await sleep(50);
  toEl.dispatchEvent(new DragEvent('dragover', { bubbles: true, clientX: tx, clientY: ty, dataTransfer }));
  await sleep(50);
  toEl.dispatchEvent(new DragEvent('drop', { bubbles: true, clientX: tx, clientY: ty, dataTransfer }));
  await sleep(50);
  fromEl.dispatchEvent(new DragEvent('dragend', { bubbles: true, clientX: tx, clientY: ty, dataTransfer }));
  
  fromEl.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, clientX: tx, clientY: ty }));
  fromEl.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, clientX: tx, clientY: ty }));

  await sleep(200);
  window.elijasAnswered.add(fromEl);
  window.elijasAnswered.add(toEl);
}

// ─── SNIPPING TOOL OVERLAY ───
function startSnippingOverlay(jobType) {
  // Remove existing overlay if any
  const existing = document.getElementById('elijas-snip-host');
  if(existing) existing.remove();

  // Create host and attach to documentElement to bypass body { overflow: hidden } constraints
  const host = document.createElement('div');
  host.id = 'elijas-snip-host';
  // Use inline !important to make it absolutely immune to page CSS
  host.setAttribute('style', `
    all: initial !important;
    position: fixed !important;
    inset: 0 !important;
    z-index: 2147483647 !important;
    display: block !important;
    pointer-events: all !important;
  `);

  // Use Shadow DOM for perfect isolation
  const shadow = host.attachShadow({ mode: 'closed' });

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position:absolute;inset:0;
    background:rgba(0,0,0,0.45);cursor:crosshair;
    font-family: system-ui, -apple-system, sans-serif;
  `;

  const box = document.createElement('div');
  box.style.cssText = `
    position:absolute;border:3px solid #c8870f;
    background:rgba(200,135,15,0.15);display:none;pointer-events:none;
    outline: 2px solid rgba(0,0,0,0.5);
    box-shadow: 0 0 0 9999px rgba(0,0,0,0.3);
  `;

  const toast = document.createElement('div');
  toast.style.cssText = `
    position:absolute;top:24px;left:50%;transform:translateX(-50%);
    background:#18181b;color:#f4f4f5;padding:10px 16px;border-radius:6px;
    font-size:13px;font-weight:600;pointer-events:none;
    border:1px solid #3f3f46;box-shadow:0 8px 32px rgba(0,0,0,0.4);
    white-space:nowrap;display:flex;align-items:center;gap:8px;
  `;
  toast.innerHTML = `<span style="color:#c8870f;">✂</span> Click and drag to select the question area`;

  const cancel = document.createElement('button');
  cancel.style.cssText = `
    position:absolute;top:24px;right:24px;
    background:#27272a;color:#a1a1aa;padding:8px 14px;border-radius:6px;
    font-size:11px;font-weight:600;cursor:pointer;border:1px solid #3f3f46;
    transition:background 0.1s;
  `;
  cancel.innerText = '✕ ESC to Cancel';
  cancel.onmouseover = () => { cancel.style.background = '#3f3f46'; cancel.style.color = '#f4f4f5'; };
  cancel.onmouseout = () => { cancel.style.background = '#27272a'; cancel.style.color = '#a1a1aa'; };
  cancel.addEventListener('click', () => host.remove());

  overlay.appendChild(box);
  overlay.appendChild(toast);
  overlay.appendChild(cancel);
  shadow.appendChild(overlay);
  document.documentElement.appendChild(host);

  let startX = 0, startY = 0, isDrawing = false;

  overlay.addEventListener('pointerdown', e => {
    if(e.target === cancel) return;
    e.preventDefault();
    isDrawing = true;
    startX = e.clientX; startY = e.clientY;
    box.style.left   = startX + 'px';
    box.style.top    = startY + 'px';
    box.style.width  = '0px';
    box.style.height = '0px';
    box.style.display = 'block';
    toast.style.display = 'none';
  });

  overlay.addEventListener('pointermove', e => {
    if(!isDrawing) return;
    e.preventDefault();
    const cx = e.clientX, cy = e.clientY;
    box.style.left   = Math.min(startX, cx) + 'px';
    box.style.top    = Math.min(startY, cy) + 'px';
    box.style.width  = Math.abs(cx - startX) + 'px';
    box.style.height = Math.abs(cy - startY) + 'px';
  });

  overlay.addEventListener('pointerup', async e => {
    if(!isDrawing) return;
    isDrawing = false;
    e.preventDefault();

    const rect = box.getBoundingClientRect();
    host.remove();

    if(rect.width < 20 || rect.height < 20) {
      if(_st) _st.local.set({ pendingJob: null, snipRect: null });
      return;
    }

    const snipRect = {
      x: rect.left, y: rect.top,
      w: rect.width, h: rect.height,
      dw: document.documentElement.clientWidth,
      dh: document.documentElement.clientHeight
    };

    if(_st) await _st.local.set({ snipRect, pendingJob: jobType });

    // Show confirmation toast
    const t = document.createElement('div');
    t.setAttribute('style', `
      all: initial !important; position: fixed !important;
      top: 24px !important; left: 50% !important; transform: translateX(-50%) !important;
      background: #18181b !important; color: #10b981 !important; padding: 12px 20px !important;
      border-radius: 8px !important; font-family: system-ui, sans-serif !important;
      font-size: 13px !important; font-weight: 600 !important; z-index: 2147483647 !important;
      box-shadow: 0 8px 32px rgba(0,0,0,0.5) !important; border: 1px solid rgba(16, 185, 129, 0.3) !important;
    `);
    t.innerText = '✓ Area selected. Resuming process...';
    document.documentElement.appendChild(t);
    setTimeout(() => t.remove(), 4000);
  });

  function onEsc(e) {
    if(e.key === 'Escape') {
      host.remove();
      if(_st) _st.local.set({ pendingJob: null, snipRect: null });
      document.removeEventListener('keydown', onEsc);
    }
  }
  document.addEventListener('keydown', onEsc);
}

// ─── MESSAGE HANDLER ───
function handleMessage(message, sender, sendResponse) {
  console.log('[ElijasGPT content] received:', message.type);

  if(message.type === 'PING') {
    sendResponse({ pong: true, version: '4.1', loaded: true });
    return true;
  }

  if(message.type === 'SCAN_PAGE') {
    try {
      const elements = scanPage();
      sendResponse({ elements, title: document.title, url: location.href, count: elements.length });
    } catch(e) {
      sendResponse({ error: e.message, elements: [] });
    }
    return true;
  }

  if(message.type === 'EXECUTE_ACTIONS') {
    (async () => {
      const results = [];
      for(const action of (message.actions || [])) {
        const res = await executeAction(action);
        results.push(res);
        console.log('[ElijasGPT] action result:', action.type, res.success ? '✓' : '✗', res.msg || res.error);
        await sleep(action.type === 'drag' ? 600 : 300);
      }
      sendResponse({ results, done: true });
    })();
    return true; // async
  }

  if(message.type === 'START_SNIPPING') {
    startSnippingOverlay(message.job || 'auto');
    sendResponse({ ok: true });
    return true;
  }

  if(message.type === 'GET_PAGE_TEXT') {
    sendResponse({ text: document.body?.innerText?.substring(0, 5000) || '' });
    return true;
  }

  if(message.type === 'SET_ORB_VISIBLE') {
    const orb = document.getElementById('elijasgpt-floating-trigger');
    if(orb) orb.style.display = message.visible ? 'block' : 'none';
    sendResponse({ ok: true });
    return true;
  }

  sendResponse({ error: 'Unknown message type: ' + message.type });
  return true;
}

// ─── REGISTER MESSAGE LISTENER ───
if(_isFirefox) {
  browser.runtime.onMessage.addListener((msg, sender) => {
    return new Promise(resolve => handleMessage(msg, sender, resolve));
  });
} else if(typeof chrome !== 'undefined' && chrome.runtime) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    handleMessage(msg, sender, sendResponse);
    return true; // keep channel open for async
  });
}

// ─── ALT+G KEYBOARD SHORTCUT ───
let _toggling = false;
window.addEventListener('keydown', async (e) => {
  if(e.altKey && e.key.toLowerCase() === 'g' && !_toggling) {
    e.preventDefault();
    e.stopPropagation();
    _toggling = true;
    try {
      if(_rt) await _rt.sendMessage({ type: 'TOGGLE_SIDEBAR' }).catch(() => {});
    } finally {
      setTimeout(() => _toggling = false, 500);
    }
  }
}, true);

// ─── FLOATING ORB ───
async function injectLauncher() {
  if(document.getElementById('elijasgpt-floating-trigger')) return;

  let orbDisabled = false;
  if(_st) {
    try {
      const r = await _st.local.get('elijasOrbDisabled');
      orbDisabled = !!(r.elijasOrbDisabled);
    } catch(e) {}
  }

  // Plain DOM orb — no complex APIs, works everywhere
  const container = document.createElement('div');
  container.id = 'elijasgpt-floating-trigger';
  container.style.cssText = [
    'position:fixed', 'bottom:22px', 'right:22px', 'z-index:2147483647',
    'width:48px', 'height:48px', 'border-radius:50%',
    'background:#c8880f', 'border:2px solid #9a6408',
    'display:' + (orbDisabled ? 'none' : 'flex'),
    'align-items:center', 'justify-content:center',
    'cursor:pointer', 'opacity:0.88',
    'box-shadow:0 3px 16px rgba(0,0,0,0.5)',
    'transition:transform 0.18s,opacity 0.18s',
    'user-select:none', 'font-size:22px', 'line-height:1'
  ].join(';');
  container.title = 'ElijasGPT (Alt+G)';
  container.textContent = '⚡';

  container.addEventListener('mouseenter', () => {
    container.style.transform = 'scale(1.12)';
    container.style.opacity = '1';
  });
  container.addEventListener('mouseleave', () => {
    container.style.transform = 'scale(1)';
    container.style.opacity = '0.88';
  });
  container.addEventListener('mousedown', () => { container.style.transform = 'scale(0.92)'; });
  container.addEventListener('mouseup',   () => { container.style.transform = 'scale(1.12)'; });

  container.addEventListener('click', e => {
    e.stopPropagation();
    e.preventDefault();
    if(_rt) _rt.sendMessage({ type: 'TOGGLE_SIDEBAR' }).catch(() => {});
  });

  document.body.appendChild(container);
  console.log('[ElijasGPT] Orb injected');
}

if(document.body) {
  injectLauncher();
} else {
  document.addEventListener('DOMContentLoaded', injectLauncher);
}

console.log('[ElijasGPT] content.js v4.1 PRO loaded on', location.href);

} // end guard
