// popup.js v4.1 PRO — Firefox Version (browser.* API)

const GEMINI_API_KEY  = "AQ.Ab8RN6IBlPFnXaFDVu7yV4tgn6S5WIAHvrKOx9O4mUbSQ9ijhQ";
const GROQ_API_KEY    = "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";
const MISTRAL_API_KEY = "5wuzyeWmYSgmAX447hJ19IpVN7hEJqEY";
const OPENAI_API_KEY  = "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";

const output       = document.getElementById("output");
const preview      = document.getElementById("preview");
const userPromptEl = document.getElementById("userPrompt");
let isRunning = false, shouldStop = false;

const STORAGE_KEY   = "inputFieldValue";
const ANSWERS_KEY   = "autoSolveAnswers";
const WELCOMED_KEY  = "elijasWelcomed";
const ORB_KEY       = "elijasOrbDisabled";
const DEBOUNCE_DELAY = 500;

const store = {
  set: async (obj) => { try { await browser.storage.local.set(obj); } catch(e) {} },
  get: async (key) => { try { const r = await browser.storage.local.get(key); return r[key]; } catch(e) { return undefined; } }
};
const saveAnswers = async a => store.set({ [ANSWERS_KEY]: a });
const loadAnswers = async () => (await store.get(ANSWERS_KEY)) ?? [];
const debounce = (fn, d) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), d); }; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ─── ERROR LOG COLLECTOR ───
const errorLog = [];
function pushErrorLog(msg) {
  const t = new Date().toLocaleTimeString('en-GB', { hour12: false });
  errorLog.push(`[${t}] ${msg}`);
  if(errorLog.length > 200) errorLog.shift();
}

// ─── CONSOLE INTERCEPTOR (full errors with stack traces) ───
(function() {
  const _orig = {
    log:   console.log.bind(console),
    warn:  console.warn.bind(console),
    error: console.error.bind(console),
    info:  console.info.bind(console)
  };
  function _push(level, args) {
    const panel = document.getElementById('console-output');
    const t = new Date().toLocaleTimeString('en-GB', { hour12: false });
    const msg = args.map(a => {
      if(a instanceof Error) return a.message + (a.stack ? '\n  ' + a.stack.split('\n').slice(0,4).join('\n  ') : '');
      try { return typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a); }
      catch(e) { return String(a); }
    }).join(' ');
    if(level === 'error' || level === 'warn') pushErrorLog(`[${level.toUpperCase()}] ${msg}`);
    if(!panel) return;
    const line = document.createElement('div');
    line.className = 'term-line term-' + level;
    line.innerHTML = `<span class="term-time">[${t}]</span><pre style="display:inline;white-space:pre-wrap;word-break:break-all;">${msg}</pre>`;
    panel.appendChild(line);
    if(panel.children.length > 400) panel.removeChild(panel.firstChild);
    panel.scrollTop = panel.scrollHeight;
  }
  console.log   = (...a) => { _orig.log(...a);   _push('log',   a); };
  console.warn  = (...a) => { _orig.warn(...a);  _push('warn',  a); };
  console.error = (...a) => { _orig.error(...a); _push('error', a); };
  console.info  = (...a) => { _orig.info(...a);  _push('info',  a); };
  window.onerror = (msg, src, line, col, err) => {
    const full = `[UNCAUGHT] ${msg} @ ${src}:${line}:${col}` + (err?.stack ? '\n' + err.stack : '');
    _push('error', [full]); pushErrorLog(full); return false;
  };
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason;
    const msg = r instanceof Error
      ? `[UNHANDLED REJECTION] ${r.message}` + (r.stack ? '\n' + r.stack : '')
      : `[UNHANDLED REJECTION] ${String(r)}`;
    _push('error', [msg]); pushErrorLog(msg);
  });
})();

// ─── STATUS HELPERS ───
function setStatus(t, type) {
  const e = document.getElementById("status-display");
  if(!e) return; e.textContent = t; e.className = type || "active";
}
function setStatusError(t) {
  const e = document.getElementById("status-display");
  if(!e) return; e.textContent = t; e.className = "error";
  setTimeout(() => { if(e.textContent === t) e.className = ""; }, 5000);
}
function setStatusWarn(t) {
  const e = document.getElementById("status-display");
  if(!e) return; e.textContent = t; e.className = "warn";
  setTimeout(() => { if(e.textContent === t) e.className = ""; }, 3000);
}
function setStatusSmall(t)    { const e = document.getElementById("status-display");  if(e) { e.textContent = t; e.className = ""; } }
function setActionLog(t)      { const e = document.getElementById("output"); if(e) e.innerHTML += `<div class="action-item"><span class="action-type">SYS</span><span class="action-desc">${t}</span></div>`; }
function showCountdownCard(s) { }
function setCountdownDisplay(t, go) {
  const e = document.getElementById("status-display");
  if(!e) return; e.textContent = `[${t}] ${go ? 'EXECUTING...' : 'INITIATING...'}`; e.className = go ? "success" : "active";
}
function setButtons(running) {
  ["autoAnswerBtn","autoSolveBtn","analyzePage","capturePage","clearAnswers"].forEach(id => {
    const b = document.getElementById(id); if(b) b.disabled = running;
  });
  const s = document.getElementById("stopBtn"); if(s) s.disabled = !running;
  const ms = document.getElementById("mini-stop"); if(ms) ms.disabled = !running;
  const maa = document.getElementById("mini-autoAnswer"); if(maa) maa.disabled = running;
  const mas = document.getElementById("mini-autoSolve"); if(mas) mas.disabled = running;
}

// ─── SCREENSHOT (no downscaling unless over 3000px) ───
function resizeDataUrl(dataUrl, maxW = 3000) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      if(img.width <= maxW) { resolve(dataUrl); return; }
      const scale = maxW / img.width;
      const c = document.createElement('canvas');
      c.width  = Math.round(img.width  * scale);
      c.height = Math.round(img.height * scale);
      const ctx = c.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.97));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

function cropScreenshot(dataUrl, rect) {
  return new Promise(resolve => {
    if(!rect || !rect.w || !rect.h) { resolve(dataUrl); return; }
    const img = new Image();
    img.onload = () => {
      // rect is in CSS pixels. Ratio maps it to actual screenshot device pixels.
      const ratio = img.width / rect.dw; 
      const cx = rect.x * ratio;
      const cy = rect.y * ratio;
      const cw = rect.w * ratio;
      const ch = rect.h * ratio;

      const c = document.createElement('canvas');
      c.width = cw; c.height = ch;
      const ctx = c.getContext('2d');
      ctx.drawImage(img, cx, cy, cw, ch, 0, 0, cw, ch);
      
      resolve(c.toDataURL('image/jpeg', 0.97));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

async function getScreenshot(snipRect = null) {
  if (snipRect && snipRect._precroppedDataUrl) {
    return snipRect._precroppedDataUrl;
  }
  try {
    let res = await browser.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT_JPEG" });
    if(res && res.dataUrl) {
      console.log('[Screenshot] JPEG ok, size:', res.dataUrl.length);
      return snipRect ? await cropScreenshot(res.dataUrl, snipRect) : res.dataUrl;
    }
    res = await browser.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" });
    if(res && res.dataUrl) {
      console.log('[Screenshot] PNG fallback ok');
      return snipRect ? await cropScreenshot(res.dataUrl, snipRect) : res.dataUrl;
    }
    console.error('[Screenshot] Both methods failed');
    return null;
  } catch(e) { console.error('[Screenshot] Error:', e.message); return null; }
}

// ─── CONTENT SCRIPT MESSAGING ───
// Advanced: PING → if dead → inject (3-layer BG system) → PING again → send
async function sendToPage(message) {
  const tabs = await browser.tabs.query({ active: true, lastFocusedWindow: true });
  if(!tabs || tabs.length === 0) throw new Error("Aktyvus langas nerastas");
  const tabId  = tabs[0].id;
  const tabUrl = tabs[0].url || "";
  console.log('[sendToPage]', message.type, '→ tab', tabId, tabUrl.substring(0,60));

  // Block truly un-injectable pages
  if(tabUrl.startsWith("about:blank") || tabUrl.startsWith("moz-extension://") ||
     tabUrl.startsWith("about:newtab") || tabUrl === "") {
    throw new Error("Šiame puslapyje plėtinys neveikia. Atidarykite bet kurį puslapį naršyklėje.");
  }

  // ── Phase 1: Quick PING ──
  async function ping() {
    try {
      const r = await browser.tabs.sendMessage(tabId, { type: "PING" });
      return r?.pong === true;
    } catch(e) { return false; }
  }

  let alive = await ping();
  console.log('[sendToPage] initial PING:', alive ? '✓' : '✗');

  if(!alive) {
    // ── Phase 2: Trigger 3-layer background injection ──
    setStatus("Įkeliamas content script (3 metodai)...");
    try {
      const injectRes = await browser.runtime.sendMessage({ type: "INJECT_CONTENT" });
      console.log('[sendToPage] Injection result:', JSON.stringify(injectRes));
    } catch(e) {
      console.warn('[sendToPage] Injection message failed:', e.message);
    }

    // ── Phase 3: PING retry after injection (up to 5 attempts) ──
    for(let attempt = 1; attempt <= 5; attempt++) {
      await sleep(500);
      alive = await ping();
      console.log('[sendToPage] Post-inject PING attempt', attempt, ':', alive ? '✓' : '✗');
      if(alive) { setStatus("Prisijungta! Vykdoma..."); break; }
      setStatus("Laukiama script'o (" + attempt + "/5)...");
    }

    if(!alive) {
      throw new Error(
        "Nepavyko prisijungti prie puslapio po 3 injekcijos metodų ir 5 bandymų. " +
        "Perkraukite puslapį (F5) ir bandykite iš karto."
      );
    }
  }

  return browser.tabs.sendMessage(tabId, message).catch(e => {
    console.error('[sendToPage] Send failed:', e.message, '| type:', message.type);
    throw new Error("Komunikacijos klaida: " + e.message + ". Perkraukite (F5).");
  });
}


// ─── COUNTDOWN ───
async function runCountdown(seconds) {
  for(let i = seconds; i > 0; i--) {
    if(shouldStop) return false;
    setCountdownDisplay(String(i), false);
    setStatus("Paruoškite klausimą ekrane...");
    await sleep(1000);
  }
  if(shouldStop) return false;
  setCountdownDisplay("Analizuojama...", true);
  setStatus("Daroma ekrano nuotrauka...");
  await sleep(400);
  return true;
}

// ─── SOLVE PROMPT (for AI answer display) ───
const SOLVER_PROMPT = `You are a strict quiz answer bot. Output ONLY the exact answers.
Zero introduction. Zero explanation. Zero greeting.
If the image does not clearly contain a question, a quiz, or a test, you MUST output ONLY: NOQUESTIONS

FORMAT — one line per question:
  Multiple choice  -> K1: 2-as — Fotosintezė
  Text input       -> K2: 1-as langelis — Vilnius
  True/False       -> K3: Kairėje — Teisinga
  Drag / Match     -> K4: "Fotosintezė" -> 2-as langelis dešinėje
  Ordering         -> K5: 1.Įvadas 2.Dalis 3.Išvada
  Dropdown         -> K6: pasirink — Lietuva
  Image match      -> K7: "Ąžuolas" -> kairysis paveikslėlis

RULES:
- Say WHERE the answer is in 1-2 words before it ("2-as", "Kairėje", "Viršuje").
- Read ACTUAL question number from screen (e.g. "14. Kokia..." = K14:).
- Lithuanian question = Lithuanian answer. English question = English answer.
- Answer ALL visible questions. Start IMMEDIATELY with K1:.
- If no questions visible: output ONLY NOQUESTIONS`;

// ─── AUTO-ANSWER PROMPT BUILDER ───
function buildAutoAnswerPrompt(elements, pageTitle) {
  const useful = elements.filter(el =>
    ['radio','radio_label','checkbox','checkbox_label','text_input','number_input','sequence_input',
     'select','textarea','textarea_like',
     'draggable','droptarget','answer_element','image','image_container',
     'label_box','sortable','button'].includes(el.type)
  ).slice(0, 80);

  const elemList = useful.map(el => {
    let line = `[${el.index}] ${el.type}: "${el.text}"`;
    if(el.rect) line += ` @(top:${el.rect.top},left:${el.rect.left})`;
    if(el.value !== undefined && el.value !== "") line += ` value="${el.value}"`;
    if(el.checked === true) line += ` [CHECKED]`;
    if((el.value && el.value.trim().length > 0) || el.checked) line += ` -- ALREADY FILLED/ANSWERED`;
    return line;
  }).join('\n');

  return `ElijasGPT V4.1 PRO — Auto Quiz Solver. Page: "${pageTitle}"

SCANNED PAGE ELEMENTS (use the index number in actions):
${elemList}

═══ RULES FOR ALREADY-ANSWERED QUESTIONS ═══
- "ALREADY FILLED/ANSWERED" = check if correct. If wrong → fix it. If correct → skip.
- If ALL visible questions already answered → ONLY output: {"type":"scroll","elementIndex":0}

═══ CRITICAL: HOW TO SOLVE EACH TYPE ═══

1) MULTIPLE CHOICE / TRUE-FALSE:
   Click the radio_label or answer_element that is the correct answer.
   Action: {"type":"click","elementIndex":N}
   ⚠ DO NOT use "select" for radio buttons. ONLY use "click".

2) DROPDOWN / SELECT MENU:
   Element type will be "select". You MUST use type "select" with the option text.
   Action: {"type":"select","elementIndex":N,"value":"EXACT option text from the list"}
   ⚠ NEVER use "click" on a "select" type element. ALWAYS use "select".
   ⚠ The value must EXACTLY match one of the options shown in the element text.

3) TEXT INPUT / FILL IN THE BLANK:
   Action: {"type":"type","elementIndex":N,"value":"your answer"}

4) OPEN TEXT / TEXTAREA:
   Action: {"type":"type","elementIndex":N,"value":"full sentence answer"}

5) SEQUENCE / ORDERING (number boxes):
   Actions: [{"type":"type","elementIndex":N,"value":"1"}, {"type":"type","elementIndex":M,"value":"2"}, ...]

6) DRAG AND DROP (connect / match):
   Use fromIndex = the draggable item, toIndex = the drop target.
   Action: {"type":"drag","fromIndex":N,"toIndex":M}
   ⚠ Issue MULTIPLE drag actions if multiple pairs need connecting.

7) PHOTO-TO-TEXT MATCHING:
   Click text label, then click matching image.
   Actions: [{"type":"click","elementIndex":textLabel}, {"type":"click","elementIndex":imageEl}]

RETURN ONLY VALID JSON. No markdown. No text before or after.
{
  "questionType": "multiple_choice|fill_in|open_text|sequence|photo_match|drag_drop|dropdown|true_false|none",
  "answer": "Short human-readable description of what you are doing and why",
  "actions": [
    {"type":"click","elementIndex":5,"reason":"Select option B — Fotosintezė"},
    {"type":"select","elementIndex":7,"value":"Lietuva","reason":"Pick Lietuva from dropdown"},
    {"type":"drag","fromIndex":2,"toIndex":9,"reason":"Drag Vanduo to first slot"}
  ]
}`;
}

// ─── API WRAPPERS ───
async function askGroq(sc, prompt, sys) {
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + GROQ_API_KEY },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [
          { role: "system", content: sys || "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: sc } }
          ]}
        ],
        temperature: 0.05, max_tokens: 1000
      })
    });
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || res.statusText;
      console.warn(`Groq ${res.status}: ${reason}`);
      setStatus(`Groq klaida (${res.status}) → Mistral...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Groq exception:", e.message); return null; }
}

async function askMistral(sc, prompt, sys) {
  try {
    const res = await fetch("https://api.mistral.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + MISTRAL_API_KEY },
      body: JSON.stringify({
        model: "mistral-medium-latest",
        messages: [
          { role: "system", content: sys || "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: sc } }
          ]}
        ],
        temperature: 0.05, max_tokens: 1000
      })
    });
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      console.warn(`Mistral ${res.status}: ${body?.error?.message || res.statusText}`);
      setStatus(`Mistral klaida (${res.status}) → Gemini...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Mistral exception:", e.message); return null; }
}

async function askGemini(sc, prompt) {
  try {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + GEMINI_API_KEY,
      { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [
            { text: prompt },
            { inlineData: { mimeType: "image/jpeg", data: sc.split(",")[1] } }
          ]}],
          generationConfig: { temperature: 0.05, maxOutputTokens: 1000 }
        })
      }
    );
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      console.warn(`Gemini ${res.status}: ${body?.error?.message || res.statusText}`);
      setStatus(`Gemini klaida (${res.status}) → ChatGPT...`);
      return null;
    }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? null;
  } catch(e) { console.warn("Gemini exception:", e.message); return null; }
}

async function askChatGPT(sc, prompt, sys) {
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + OPENAI_API_KEY },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: sys || "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: sc } }
          ]}
        ],
        temperature: 0.05, max_tokens: 1000
      })
    });
    if(!res.ok) {
      const body = await res.json().catch(() => ({}));
      console.warn(`ChatGPT ${res.status}: ${body?.error?.message || res.statusText}`);
      setStatus(`ChatGPT klaida (${res.status})`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("ChatGPT exception:", e.message); return null; }
}

function parseAIJson(text) {
  if(!text) return null;
  try { return JSON.parse(text.trim()); } catch(e) {}
  const m = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if(m) { try { return JSON.parse(m[1].trim()); } catch(e) {} }
  const s = text.indexOf('{'), en = text.lastIndexOf('}');
  if(s !== -1 && en !== -1) { try { return JSON.parse(text.substring(s, en+1)); } catch(e) {} }
  console.warn('[parseAIJson] Could not parse:', text.substring(0, 200));
  return null;
}

// ─── AI ORCHESTRATOR (with smart cascade + logging) ───
async function askAIForActions(screenshot, elements, pageTitle) {
  const prompt = buildAutoAnswerPrompt(elements, pageTitle);
  const sc = await resizeDataUrl(screenshot);
  const sys = "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON. No markdown. No text.";

  setStatus("Groq analizuoja...");
  const r = await askGroq(sc, prompt, sys);
  if(r) { const p = parseAIJson(r); if(p) { console.log('[AI] Groq answered, type:', p.questionType); return p; } }

  setStatus("Mistral analizuoja...");
  await sleep(500);
  const m = await askMistral(sc, prompt, sys);
  if(m) { const p = parseAIJson(m); if(p) { console.log('[AI] Mistral answered'); return p; } }

  setStatus("Gemini analizuoja...");
  await sleep(500);
  const g = await askGemini(sc, prompt);
  if(g) { const p = parseAIJson(g); if(p) { console.log('[AI] Gemini answered'); return p; } }

  setStatus("ChatGPT analizuoja...");
  await sleep(500);
  const c = await askChatGPT(sc, prompt, sys);
  if(c) { const p = parseAIJson(c); if(p) { console.log('[AI] ChatGPT answered'); return p; } }

  return null;
}

async function askAISolve(screenshot) {
  const sc = await resizeDataUrl(screenshot);
  const sys = "You are a quiz answer bot. Output ONLY direct answers. No introduction. Start with K1:";

  setStatus("Groq analizuoja...");
  const r = await askGroq(sc, SOLVER_PROMPT, sys);
  if(r && r.trim() && r.trim() !== "NOQUESTIONS") return { text: r.trim(), source: "Groq" };

  setStatus("Mistral analizuoja...");
  const m = await askMistral(sc, SOLVER_PROMPT, sys);
  if(m && m.trim() && m.trim() !== "NOQUESTIONS") return { text: m.trim(), source: "Mistral" };

  setStatus("Gemini analizuoja...");
  const g = await askGemini(sc, SOLVER_PROMPT);
  if(g && g.trim() && g.trim() !== "NOQUESTIONS") return { text: g.trim(), source: "Gemini" };

  setStatus("ChatGPT analizuoja...");
  const ct = await askChatGPT(sc, SOLVER_PROMPT, sys);
  if(ct && ct.trim() && ct.trim() !== "NOQUESTIONS") return { text: ct.trim(), source: "ChatGPT" };

  // Check if any returned NOQUESTIONS
  if([r,m,g,ct].some(x => x?.trim() === "NOQUESTIONS")) return { text: "NOQUESTIONS", source: "AI" };
  return null;
}

// ─── OUTPUT RENDERER ───
function renderV4FormattedAnswers(answersArray) {
  if(!output) return;
  output.innerHTML = "";
  if(!answersArray || answersArray.length === 0) {
    output.textContent = "Nėra gautų rezultatų."; return;
  }
  answersArray.forEach(item => {
    const card = document.createElement("div");
    card.className = "q-block";
    const text = ((item.text || item) + "").trim();
    const lines = text.split("\n").filter(l => l.trim().length > 0);
    let html = "";
    lines.forEach(line => {
      const t = line.trim();
      if(/^\[/.test(t) || t.startsWith("📌")) {
        html += `<div class="q-title">${t}</div>`;
      } else if(/^K\d+:/i.test(t)) {
        const colon = t.indexOf(":");
        const ref = t.substring(0, colon + 1);
        const ans = t.substring(colon + 1).trim();
        if(/->|nutempk|sujunk|→/i.test(ans)) {
          html += `<div class="q-row"><b class="q-ref">${ref}</b> ⚡ ${ans}</div>`;
        } else {
          html += `<div class="q-row"><b class="q-ref">${ref}</b> 🎯 ${ans}</div>`;
        }
      } else if(/^[✓✗]/.test(t)) {
        const ok = t.startsWith("✓");
        html += `<div class="q-row" style="color:${ok ? "#5cb85c" : "#c05050"}">${t}</div>`;
      } else {
        html += `<div class="q-row">${t}</div>`;
      }
    });
    card.innerHTML = html;
    output.appendChild(card);
  });
}

// ─── AUTO-ANSWER MAIN LOOP ───
async function autoAnswer(snipRect = null) {
  if(isRunning) return;
  isRunning = true; shouldStop = false;
  setButtons(true); showCountdownCard(true);
  output.textContent = snipRect ? "Pradedamas AREA AUTO-ANSWER..." : "Pradedamas AUTO-ANSWER..."; setActionLog("");

  let totalDone = 0, round = 0, noQStreak = 0, failStreak = 0;
  const MAX = 100, MAX_NO_Q = 4, MAX_FAIL = 5;

  while(round < MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    setCountdownDisplay("Nuskaitoma...", true);
    setStatus("Nuskaitomi puslapio elementai...");
    let pageData;
    try {
      pageData = await sendToPage({ type: "SCAN_PAGE" });
    } catch(e) {
      console.error('[autoAnswer] Scan failed:', e.message);
      setStatusError("⚠ " + e.message);
      setCountdownDisplay("Laukiama...", false);
      failStreak++;
      if(failStreak >= MAX_FAIL) { setStatusError("Per daug klaidų. Perkraukite puslapį."); break; }
      round--; await sleep(3000); continue;
    }

    const elements = pageData?.elements || [];
    console.log('[autoAnswer] Scanned elements:', elements.length, 'types:', [...new Set(elements.map(e=>e.type))].join(','));
    setActionLog("Elementų: " + elements.length);

    const screenshot = await getScreenshot(snipRect);
    if(!screenshot) {
      setStatusWarn("⚠ Nuotrauka nepavyko, bandoma dar kartą...");
      failStreak++;
      if(failStreak >= MAX_FAIL) { setStatusError("Nuotraukų klaida. Perkraukite puslapį."); break; }
      round--; await sleep(2000); continue;
    }

    setCountdownDisplay("AI mąsto...", true);
    const aiResult = await askAIForActions(screenshot, elements, pageData.title || "");

    if(!aiResult) {
      failStreak++;
      setCountdownDisplay("Bandoma...", false);
      setStatusWarn("⚠ AI klaida (" + failStreak + "/" + MAX_FAIL + ") — tikriname ryšį...");
      if(failStreak >= MAX_FAIL) { setStatusError("Visos API nepasiekiamos. Patikrinkite internetą."); break; }
      round--; await sleep(4000); continue;
    }
    failStreak = 0;

    console.log('[autoAnswer] AI result:', JSON.stringify(aiResult).substring(0, 300));

    if(aiResult.questionType === "none" || !aiResult.actions || aiResult.actions.length === 0) {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatusWarn("⚠ Klausimų nerasta (" + noQStreak + "/" + MAX_NO_Q + "). Nustatykite klausimą ekrane.");
      await sleep(1500);
      if(noQStreak >= MAX_NO_Q) { setStatusError("❌ Baigta — klausimų nerasta."); setCountdownDisplay("Baigta!", false); break; }
      continue;
    }
    noQStreak = 0;

    setCountdownDisplay("Vykdoma!", true);
    setStatus("Atsakymas: " + (aiResult.answer || "?") + " [" + aiResult.questionType + "]");
    setActionLog("Vykdomi " + aiResult.actions.length + " veiksmai...");

    let execResult;
    try {
      execResult = await sendToPage({ type: "EXECUTE_ACTIONS", actions: aiResult.actions });
    } catch(e) {
      console.error('[autoAnswer] Execute failed:', e.message);
      setStatusWarn("⚠ Vykdymo klaida: " + e.message);
      failStreak++; round--; await sleep(2000); continue;
    }

    const results = execResult?.results || [];
    const passed  = results.filter(r => r.success).length;
    const failed  = results.filter(r => !r.success);
    if(failed.length > 0) {
      failed.forEach(f => console.warn('[autoAnswer] Action failed:', JSON.stringify(f)));
    }
    totalDone++;

    const log = results.map((r,i) => (r.success ? "✓" : "✗") + " " + (r.msg || r.error || "veiksmas " + (i+1))).join("\n");
    const summaryText = `📌 Ratas ${round} [${aiResult.questionType}]\n• ${aiResult.answer || "?"}\n• Atlikta ${passed}/${results.length}\n${log}`;

    const currentCards = Array.from(output.querySelectorAll(".q-block")).map(c => ({ text: c.innerText }));
    currentCards.unshift({ text: summaryText });
    renderV4FormattedAnswers(currentCards);

    setStatus("✓ Ratas " + round + " baigtas! " + passed + "/" + results.length + " veiksmų. Viso: " + totalDone);
    setCountdownDisplay("Atlikta!", true);
    setActionLog(log.split('\n')[0] || "");
    await sleep(2000);
  }

  if(shouldStop) { setStatus("Sustabdyta. Atlikta: " + totalDone); setCountdownDisplay("Sustabdyta", false); }
  await sleep(2000);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Baigta: " + totalDone + " atsakyta.");
  isRunning = false;
}

// ─── AUTO-SOLVE MAIN LOOP ───
async function autoSolvePage(snipRect = null) {
  if(isRunning) return;
  isRunning = true; shouldStop = false;
  setButtons(true); showCountdownCard(true);
  let allAnswers = [];
  await saveAnswers(allAnswers);
  output.textContent = snipRect ? "Pradedamas AREA AUTO-SOLVE..." : "Pradedamas AUTO-SOLVE...";
  let round = 0, noQStreak = 0, failStreak = 0;
  const MAX = 100, MAX_NO_Q = 3, MAX_FAIL = 5;

  while(round < MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    const screenshot = await getScreenshot(snipRect);
    if(!screenshot) {
      failStreak++;
      setStatusWarn("⚠ Nuotrauka nepavyko (" + failStreak + "/" + MAX_FAIL + ")...");
      if(failStreak >= MAX_FAIL) { setStatusError("Nuotraukų klaida."); break; }
      round--; await sleep(2000); continue;
    }

    setCountdownDisplay("Analizuojama...", true);
    const result = await askAISolve(screenshot);

    if(!result) {
      failStreak++;
      setStatusWarn("⚠ API klaida (" + failStreak + "/" + MAX_FAIL + ") — bandoma dar...");
      if(failStreak >= MAX_FAIL) { setStatusError("Visos API nepasiekiamos."); break; }
      round--; await sleep(4000); continue;
    }
    failStreak = 0;

    const trimmed = result.text.trim();
    if(trimmed === "" || trimmed.toUpperCase() === "NOQUESTIONS") {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatusWarn("⚠ Klausimas nerastas (" + noQStreak + "/" + MAX_NO_Q + ").");
      await sleep(1000);
      if(noQStreak >= MAX_NO_Q) { setStatusError("❌ Baigta — klausimų nerasta."); setCountdownDisplay("Baigta!", false); break; }
    } else {
      noQStreak = 0;
      allAnswers.push({ text: `[Klausimas ${round} — ${result.source}]\n${trimmed}` });
      renderV4FormattedAnswers(allAnswers);
      await saveAnswers(allAnswers);
      setStatus("✓ Klausimas " + round + " (" + result.source + ")! Viso: " + allAnswers.length);
      setCountdownDisplay("Gauta!", true);
      await sleep(1800);
    }
  }

  if(shouldStop) { setStatus("Sustabdyta. Išsaugota: " + allAnswers.length); setCountdownDisplay("Sustabdyta", false); }
  await sleep(2000);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Solve: " + allAnswers.length + " atsakymai.");
  isRunning = false;
}

// ─── ANALYZE PAGE ───
async function analyzePage() {
  const userCustom = userPromptEl.value.trim();
  const prompt = userCustom ? (userCustom + "\n\n" + SOLVER_PROMPT) : SOLVER_PROMPT;
  setStatusSmall("Analizuojama..."); output.textContent = "Analizuojama...";
  const raw = await getScreenshot();
  if(!raw) { setStatusSmall("Nuotrauka nepavyko."); output.textContent = "Nepavyko padaryti nuotraukos."; return; }
  const sc  = await resizeDataUrl(raw);
  const sys = "You are a quiz answer bot. Output ONLY direct answers. No intro. Start with K1:";
  let text = null, src = "";
  text = await askGroq(sc, prompt, sys); src = "Groq";
  if(!text) { text = await askMistral(sc, prompt, sys); src = "Mistral"; }
  if(!text) { text = await askGemini(sc, prompt); src = "Gemini"; }
  if(!text) { text = await askChatGPT(sc, prompt, sys); src = "ChatGPT"; }
  if(text) {
    renderV4FormattedAnswers([{ text: `[Analizė — ${src}]\n${text}` }]);
    setStatusSmall("Atlikta — " + src + ".");
  } else { output.textContent = "Visos API nepavyko."; setStatusSmall("Klaida."); }
}

// ─── WELCOME SCREEN ───
async function initWelcome() {
  const welcomed = await store.get(WELCOMED_KEY);
  const overlay = document.getElementById("welcome-overlay");
  if(welcomed) { overlay.classList.add("hidden"); return; }

  const agreeCheck = document.getElementById("agreeCheck");
  const welcomeBtn = document.getElementById("welcomeBtn");
  
  const updateBtn = () => { welcomeBtn.disabled = !agreeCheck.checked; };
  agreeCheck.addEventListener("change", updateBtn);
  agreeCheck.addEventListener("input", updateBtn);
  agreeCheck.addEventListener("click", updateBtn);

  welcomeBtn.addEventListener("click", async () => {
    await store.set({ [WELCOMED_KEY]: true });
    overlay.style.animation = "none";
    overlay.style.opacity = "0";
    overlay.style.transition = "opacity 0.3s";
    setTimeout(() => overlay.classList.add("hidden"), 300);
  });
}

// ─── ORB SETTING ───
async function initOrbSetting() {
  const orbToggle = document.getElementById("orbToggle");
  if(!orbToggle) return;
  const disabled = await store.get(ORB_KEY);
  orbToggle.checked = !disabled;
  orbToggle.addEventListener("change", async () => {
    const isDisabled = !orbToggle.checked;
    await store.set({ [ORB_KEY]: isDisabled });
    // Tell any active tab to update orb visibility
    try {
      const tabs = await browser.tabs.query({ active: true, lastFocusedWindow: true });
      if(tabs[0]) {
        browser.tabs.sendMessage(tabs[0].id, { type: "SET_ORB_VISIBLE", visible: !isDisabled }).catch(() => {});
      }
    } catch(e) {}
  });
}

// ─── ERROR REPORT MODAL ───
function openErrorModal() {
  const modal = document.getElementById("error-modal");
  const content = document.getElementById("errorReportContent");
  if(!modal || !content) return;
  if(errorLog.length === 0) {
    content.textContent = "Klaidų nerasta. Viskas gerai!";
  } else {
    const info = [
      `ElijasGPT v4.1 PRO Error Report`,
      `Time: ${new Date().toISOString()}`,
      `Browser: ${navigator.userAgent}`,
      `--- Errors ---`,
      ...errorLog
    ].join('\n');
    content.textContent = info;
  }
  modal.classList.add("open");
}

// ─── SNIPPING STORAGE WATCHER ───
// Firefox sidebar stays open, so DOMContentLoaded won't re-fire after snip.
// Instead, watch storage for snipRect to appear — react immediately.
const _snipRuntime = typeof browser !== 'undefined' ? browser : chrome;
_snipRuntime.storage.onChanged.addListener((changes, area) => {
  if(area !== 'local') return;
  if(changes.snipRect && changes.snipRect.newValue && !isRunning) {
    const snipRect  = changes.snipRect.newValue;
    const jobChange = changes.pendingJob;
    const job = jobChange?.newValue || 'auto';
    console.log('[snip watcher] snipRect changed, job:', job, snipRect);
    // Clear storage so we don't re-trigger
    store.set({ pendingJob: null, snipRect: null });
    setStatus('Sritis pasirinkta! Pradedama...');
    setTimeout(() => {
      if(job === 'auto') autoAnswer(snipRect);
      else if(job === 'solve') autoSolvePage(snipRect);
    }, 300);
  }
});

// ─── EVENT LISTENERS ───
document.getElementById("autoAnswerBtn").addEventListener("click", () => autoAnswer(null));
document.getElementById("autoSolveBtn").addEventListener("click", () => autoSolvePage(null));
document.getElementById("stopBtn").addEventListener("click", () => { shouldStop = true; setStatus("Stabdoma..."); });
document.getElementById("analyzePage")?.addEventListener("click", analyzePage);

document.getElementById("snipAutoBtn")?.addEventListener("click", async () => {
  if(isRunning) { setStatus("Sistema užimta. Sustabdykite procesą. (System busy)"); return; }
  try {
    await store.set({ pendingJob: 'auto', snipRect: null });
    setStatus("Pažymėkite sritį... (Select area on page)");
    await sendToPage({ type: 'START_SNIPPING', job: 'auto' });
    if(typeof browser === 'undefined') window.close();
  } catch(e) {
    setStatusError("Klaida (Error): " + e.message);
  }
});

document.getElementById("snipSolveBtn")?.addEventListener("click", async () => {
  if(isRunning) { setStatus("Sistema užimta. Sustabdykite procesą. (System busy)"); return; }
  try {
    await store.set({ pendingJob: 'solve', snipRect: null });
    setStatus("Pažymėkite sritį... (Select area on page)");
    await sendToPage({ type: 'START_SNIPPING', job: 'solve' });
    if(typeof browser === 'undefined') window.close();
  } catch(e) {
    setStatusError("Klaida (Error): " + e.message);
  }
});



document.getElementById("capturePage")?.addEventListener("click", async () => {
  setStatusSmall("Daroma nuotrauka...");
  const raw = await getScreenshot();
  if(raw) {
    const s = await resizeDataUrl(raw);
    if(preview) { preview.src = s; preview.style.display = "block"; }
    setStatusSmall("✓ Nuotrauka padaryta.");
  } else {
    setStatusSmall("Nuotraukos klaida.");
  }
});

document.getElementById("clearAnswers")?.addEventListener("click", async () => {
  await browser.storage.local.remove(ANSWERS_KEY);
  if(output) output.textContent = "Nėra gautų rezultatų.";
  if(preview) { preview.style.display = "none"; preview.src = ""; }
  setStatusSmall("Išvalyta.");
});

document.querySelectorAll(".chip").forEach(chip => {
  chip.addEventListener("click", () => { userPromptEl.value = chip.getAttribute("data-prompt"); });
});

const copyBtn = document.getElementById("copyOutputBtn");
if(copyBtn) {
  copyBtn.addEventListener("click", () => {
    const text = output.innerText || output.textContent;
    if(text) navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = "Kopijuota! (Copied) ✓";
      setTimeout(() => copyBtn.textContent = "Kopijuoti (Copy)", 2000);
    });
  });
}

// ─── MINI BAR & CONSOLE UI ───
const fullApp  = document.getElementById("full-app");
const miniBar  = document.getElementById("mini-bar");
const minBtn   = document.getElementById("minimizeBtn");
const expandBtn= document.getElementById("mini-expand");
const termPanel= document.getElementById("console-panel");
const termBtn  = document.getElementById("consoleToggleBtn");

if(minBtn && fullApp && miniBar) {
  minBtn.addEventListener("click", () => {
    fullApp.style.display = "none";
    miniBar.style.display = "flex";
  });
}
if(expandBtn && fullApp && miniBar) {
  expandBtn.addEventListener("click", () => {
    miniBar.style.display = "none";
    fullApp.style.display = "flex";
  });
}
if(termBtn && termPanel) {
  termBtn.addEventListener("click", () => {
    const open = termPanel.classList.toggle("open");
    document.body.classList.toggle("console-open", open);
    termBtn.classList.toggle("active", open);
  });
}
document.getElementById("consoleClearBtn")?.addEventListener("click", () => {
  const p = document.getElementById("console-output");
  if(p) p.innerHTML = "";
});
document.getElementById("consoleCloseBtn")?.addEventListener("click", () => {
  termPanel?.classList.remove("open");
  document.body.classList.remove("console-open");
  termBtn?.classList.remove("active");
});

document.getElementById("mini-autoAnswer")?.addEventListener("click", () => autoAnswer(null));
document.getElementById("mini-autoSolve")?.addEventListener("click", () => autoSolvePage(null));
document.getElementById("mini-stop")?.addEventListener("click", () => { shouldStop = true; setStatus("Stabdoma..."); });

// Error report modal
document.getElementById("errorReportBtn")?.addEventListener("click", openErrorModal);
document.getElementById("errorModalClose")?.addEventListener("click", () => document.getElementById("error-modal").classList.remove("open"));
document.getElementById("errorModalClose2")?.addEventListener("click", () => document.getElementById("error-modal").classList.remove("open"));
document.getElementById("copyErrorBtn")?.addEventListener("click", () => {
  const content = document.getElementById("errorReportContent");
  if(content) navigator.clipboard.writeText(content.textContent).then(() => {
    document.getElementById("copyErrorBtn").textContent = "✓ Nukopijuota!";
    setTimeout(() => document.getElementById("copyErrorBtn").textContent = "📋 Kopijuoti", 2000);
  });
});

// ─── INIT ───
document.addEventListener("DOMContentLoaded", async () => {
  await initWelcome();
  await initOrbSetting();

  // Check if we are resuming from a snipping tool job
  const pending = await store.get('pendingJob');
  const snipRect = await store.get('snipRect');
  if(pending && snipRect) {
    await store.set({ pendingJob: null, snipRect: null });
    setStatus("Karpomas ekranas...");
    if(pending === 'auto') {
      setTimeout(() => autoAnswer(snipRect), 500);
    } else if(pending === 'solve') {
      setTimeout(() => autoSolvePage(snipRect), 500);
    }
  } else {
    // Standard resume
    const saved = await loadAnswers();
    if(saved.length > 0) {
      renderV4FormattedAnswers(saved);
      setStatusSmall("Užkrauta " + saved.length + " išsaugotų.");
    }
  }

  console.log('[ElijasGPT] v4.1 PRO popup loaded. APIs: Groq/Mistral/Gemini/ChatGPT');
});

// ─── DISCORD WEBHOOK ───
const DISCORD_WEBHOOK = "YOUR_DISCORD_WEBHOOK_URL_HERE"; // Vartotojas pasikeis šį URL

document.getElementById("sendReportBtn")?.addEventListener("click", async () => {
  const content = document.getElementById("errorReportContent")?.textContent || "Nėra klaidų";
  const btn = document.getElementById("sendReportBtn");
  if(DISCORD_WEBHOOK === "YOUR_DISCORD_WEBHOOK_URL_HERE") {
    btn.textContent = "Nenustatytas Webhook URL!";
    setTimeout(() => btn.textContent = "Išsiųsti Kūrėjui", 3000);
    return;
  }
  
  btn.textContent = "Siunčiama...";
  btn.disabled = true;
  try {
    await fetch(DISCORD_WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: "🚨 **ElijasGPT Nauja Klaida** 🚨\n```text\n" + content.substring(0, 1900) + "\n```"
      })
    });
    btn.textContent = "✓ Išsiųsta!";
  } catch(e) {
    btn.textContent = "Klaida siunčiant";
  }
  setTimeout(() => { btn.textContent = "Išsiųsti Kūrėjui"; btn.disabled = false; }, 3000);
});
