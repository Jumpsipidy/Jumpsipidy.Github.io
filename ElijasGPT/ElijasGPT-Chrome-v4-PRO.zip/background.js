// background.js — ElijasGPT V4 Chrome
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);

// Handle Alt+4 command from manifest shortcut (this works reliably as a keyboard command)
chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-sidebar") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) {
        // Chrome MV3: sidePanel.open() works from commands/action context
        chrome.sidePanel.open({ tabId: tabs[0].id }).catch(() => {
          chrome.sidePanel.open({ windowId: tabs[0].windowId }).catch(console.error);
        });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // OPEN_SIDEBAR — called by the floating ⚡ button and Alt+4 in content script
  // Note: Chrome MV3 restricts sidePanel.open() to user-gesture contexts only.
  // The floating button click IS a user gesture, so this works when triggered by click.
  // Alt+4 is handled above via chrome.commands which also has the right context.
  if (message.type === "OPEN_SIDEBAR") {
    const tab = sender.tab;
    if (tab) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(() => {
        chrome.sidePanel.open({ windowId: tab.windowId }).catch(console.error);
      });
      sendResponse({ success: true });
    }
    return true;
  }

  if (message.type === "CAPTURE_SCREENSHOT_JPEG") {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (chrome.runtime.lastError || !tabs || tabs.length === 0) {
        sendResponse({ error: "No active tab found" }); return;
      }
      chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: "jpeg", quality: 95 }, (dataUrl) => {
        if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
        else sendResponse({ dataUrl });
      });
    });
    return true;
  }

  if (message.type === "CAPTURE_SCREENSHOT") {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
      if (chrome.runtime.lastError || !tabs || tabs.length === 0) {
        sendResponse({ error: "No active tab found" }); return;
      }
      chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
        else sendResponse({ dataUrl });
      });
    });
    return true;
  }
});
