// popup.js v4.0 — ElijasGPT V4 Engine

const GEMINI_API_KEY  = "AIzaSyDs761z8dY-JyuQv21TIeadogXyFstPbwk";
const GROQ_API_KEY    = "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";
const MISTRAL_API_KEY = "5wuzyeWmYSgmAX447hJ19IpVN7hEJqEY";
const OPENAI_API_KEY  = "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";

const output       = document.getElementById("output");
const preview      = document.getElementById("preview");
const userPromptEl = document.getElementById("userPrompt");
let isRunning = false, shouldStop = false;

const STORAGE_KEY = "inputFieldValue", ANSWERS_KEY = "autoSolveAnswers", DEBOUNCE_DELAY = 500;
const saveValue   = async v  => { try { await chrome.storage.local.set({ [STORAGE_KEY]: v }); } catch(e) {} };
const loadValue   = async () => { try { const r = await chrome.storage.local.get(STORAGE_KEY); return r[STORAGE_KEY]??""; } catch(e){return "";} };
const saveAnswers = async a  => { try { await chrome.storage.local.set({ [ANSWERS_KEY]: a }); } catch(e) {} };
const loadAnswers = async () => { try { const r = await chrome.storage.local.get(ANSWERS_KEY); return r[ANSWERS_KEY]??[]; } catch(e){return [];} };
const debounce    = (fn,d)   => { let t; return (...a) => { clearTimeout(t); t=setTimeout(()=>fn(...a),d); }; };
const sleep       = ms       => new Promise(r => setTimeout(r, ms));

// ─── CONSOLE INTERCEPTOR ───
(function() {
  const _orig = { log: console.log.bind(console), warn: console.warn.bind(console), error: console.error.bind(console), info: console.info.bind(console) };
  function _pushTerm(level, args) {
    const panel = document.getElementById('console-output');
    if(!panel) return;
    const line = document.createElement('div');
    line.className = 'term-line term-' + level;
    const t = new Date().toLocaleTimeString('en-GB', { hour12: false });
    const msg = args.map(a => { try { return typeof a === 'object' ? JSON.stringify(a, null, 0) : String(a); } catch(e) { return String(a); } }).join(' ');
    line.innerHTML = `<span class="term-time">[${t}]</span>${msg}`;
    panel.appendChild(line);
    if(panel.children.length > 150) panel.removeChild(panel.firstChild);
    panel.scrollTop = panel.scrollHeight;
  }
  console.log   = (...a) => { _orig.log(...a);   _pushTerm('log',   a); };
  console.warn  = (...a) => { _orig.warn(...a);  _pushTerm('warn',  a); };
  console.error = (...a) => { _orig.error(...a); _pushTerm('error', a); };
  console.info  = (...a) => { _orig.info(...a);  _pushTerm('info',  a); };
  window.onerror = (msg, src, line) => { console.error(`[onerror] ${msg} @ ${src}:${line}`); };
})();

// ─── STATUS HELPERS ───
function setStatus(t, type) {
  const e = document.getElementById("status");
  if(!e) return;
  e.textContent = t;
  e.className = type || "";
}
function setStatusError(t) {
  const e = document.getElementById("status");
  if(!e) return;
  e.textContent = t;
  e.className = "error";
  setTimeout(() => { if(e.textContent === t) e.className = ""; }, 4000);
}
function setStatusWarn(t) {
  const e = document.getElementById("status");
  if(!e) return;
  e.textContent = t;
  e.className = "warn";
  setTimeout(() => { if(e.textContent === t) e.className = ""; }, 3000);
}
function setStatusSmall(t)  { const e=document.getElementById("status-small"); if(e) e.textContent=t; }
function setActionLog(t)    { const e=document.getElementById("action-log");   if(e) e.textContent=t; }
function showCountdownCard(s){ const e=document.getElementById("countdown-card"); if(e) e.style.display=s?"block":"none"; }
function setCountdownDisplay(t, go) {
  const e=document.getElementById("countdown-display");
  if(!e) return; e.textContent=t; e.style.display="block"; e.className=go?"go":"";
}
function setButtons(running) {
  ["autoAnswerBtn","autoSolveBtn","analyzePage","capturePage","clearAnswers"].forEach(id=>{
    const b=document.getElementById(id); if(b) b.disabled=running;
  });
  const s=document.getElementById("stopBtn"); if(s) s.disabled=!running;
  const ms=document.getElementById("mini-stop"); if(ms) ms.disabled=!running;
  const maa=document.getElementById("mini-autoAnswer"); if(maa) maa.disabled=running;
  const mas=document.getElementById("mini-autoSolve"); if(mas) mas.disabled=running;
}

// ─── 3-WAY SCREENSHOT SYSTEM & HIGH QUALITY ───
// High quality (2560px) to prevent AI hallucination and blurriness.
function resizeDataUrl(dataUrl, maxW = 2560) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      if(img.width <= maxW && dataUrl.startsWith("data:image/jpeg")) {
        resolve(dataUrl); // Already high quality JPEG and not oversized
        return;
      }
      const scale = Math.min(1, maxW / img.width);
      const w = Math.round(img.width  * scale);
      const h = Math.round(img.height * scale);
      const c = document.createElement("canvas");
      c.width = w; c.height = h;
      const ctx = c.getContext("2d");
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(img, 0, 0, w, h);
      resolve(c.toDataURL("image/jpeg", 0.95)); // Highest quality JPEG
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

async function getScreenshot() {
  return new Promise(resolve => {
    // Way 1: High quality JPEG direct from background
    chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT_JPEG" }, res1 => {
      if(!chrome.runtime.lastError && res1 && res1.dataUrl) return resolve(res1.dataUrl);
      
      // Way 2: Standard PNG fallback
      chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" }, res2 => {
        if(!chrome.runtime.lastError && res2 && res2.dataUrl) return resolve(res2.dataUrl);
        
        // Way 3: Try to request through active tab
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if(!tabs[0]) return resolve(null);
          chrome.tabs.sendMessage(tabs[0].id, { type: "PAGE_CAPTURE" }, res3 => {
             resolve(res3?.dataUrl || null);
          });
        });
      });
    });
  });
}

// --- CONTENT SCRIPT MESSAGING ---
async function sendToPage(message) {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if(!tabs || tabs.length === 0) throw new Error("Aktyvus naršyklės langas nerastas");
  const tabId = tabs[0].id;
  const tabUrl = tabs[0].url || "";
  if(tabUrl.startsWith("chrome://") || tabUrl.startsWith("chrome-extension://") || tabUrl.startsWith("about:"))
    throw new Error("Šiame puslapyje plėtinys neveikia. Atidarykite testų puslapį.");

  const alive = await new Promise(resolve => {
    chrome.tabs.sendMessage(tabId, { type: "PING" }, res => {
      chrome.runtime.lastError;
      resolve(res?.pong === true);
    });
  });

  if(!alive) {
    setStatus("Prijungiamas pagelbininkas į puslapį...");
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      await sleep(400);
    } catch(e) {
      throw new Error("Nepavyko prijungti script'o: " + e.message + ". Perkraukite puslapį.");
    }
  }

  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, res => {
      if(chrome.runtime.lastError) reject(new Error("Puslapis neprieinamas. Prašome perkrauti (F5) naršyklės langą ir bandyti dar kartą!"));
      else resolve(res);
    });
  });
}

// --- COUNTDOWN ---
async function runCountdown(seconds) {
  for(let i=seconds; i>0; i--) {
    if(shouldStop) return false;
    setCountdownDisplay(String(i), false);
    setStatus("Nustatykite klausimą ekrane dabar!");
    await sleep(1000);
  }
  if(shouldStop) return false;
  setCountdownDisplay("Analizuojama...", true);
  setStatus("Daroma ekrano nuotrauka...");
  await sleep(300);
  return true;
}

// --- V4 PROMPTS ---
// CRITICAL: This prompt is engineered to suppress all preamble/greeting/explanation from the AI.
const SOLVER_PROMPT = `You are a strict quiz answer bot. Output ONLY the exact answers. 
Zero introduction. Zero explanation. Zero greeting.
If the image does not clearly contain a question, a quiz, or a test, you MUST output ONLY the word: NOQUESTIONS

FORMAT — one line per question:
  Multiple choice  -> K1: 2-as (arba Kairėje/Dešinėje) — Fotosintezė
  Text input       -> K2: 1-as langelis — Vilnius
  True/False       -> K3: Kairėje — Teisinga
  Drag / Match     -> K4: "Fotosintezė" -> 2-as langelis dešinėje
  Ordering         -> K5: 1.Įvadas 2.Dalis 3.Išvada
  Dropdown         -> K6: 1-as meniu — Lietuva
  Image match      -> K7: "Ąžuolas" -> kairysis paveikslėlis

RULES:
- You MUST quickly say WHERE the answer is located in 1-2 words before the answer (e.g., "2-as", "Kairėje", "Viršuje", "3-ias langelis").
- Read the ACTUAL question number from the screen. If it's "14. Kokia...", output K14:. If no number, use K1, K2.
- If there are ANY questions, start IMMEDIATELY with KN: (no "I can see", no "Hello").
- Lithuanian question = Lithuanian answer. English question = English answer.
- Answer ALL visible questions.
- If there are no questions visible, or it's just a blank screen/menu/login, output ONLY: NOQUESTIONS
- DO NOT write anything after the last answer line.`;


function buildAutoAnswerPrompt(elements, pageTitle) {
  const useful = elements.filter(el =>
    ['radio','radio_label','checkbox','checkbox_label','text_input','number_input','sequence_input',
     'select','textarea','textarea_like',
     'draggable','droptarget','answer_element','image','image_container',
     'label_box','sortable','button'].includes(el.type)
  ).slice(0, 60);

  const elemList = useful.map(el => {
    let line = `[${el.index}] ${el.type}: "${el.text}"`;
    if(el.rect) line += ` @(${el.rect.top},${el.rect.left},w:${el.rect.w},h:${el.rect.h})`;
    if(el.value !== undefined && el.value !== "") line += ` value="${el.value}"`;
    if(el.checked === true || (el.value && el.value.trim().length > 0)) line += ` -- ALREADY FILLED/ANSWERED`;
    return line;
  }).join('\n');

  return `ElijasGPT V4 Auto Quiz Solver. Page: "${pageTitle}"

PAGE ELEMENTS (index number = use in actions):
${elemList}

IMPORTANT RULES FOR OVERLAPPING / SOLVED QUESTIONS:
- If an element is marked as "ALREADY FILLED/ANSWERED", CHECK if the current answer is correct!
- If the filled answer is WRONG, output an action to fix/overwrite it with the correct answer.
- If the filled answer is CORRECT, DO NOT output any action for it. Move on to the next question.
- If ALL visible questions are already correctly answered, you MUST output ONLY this action to scroll down: {"type":"scroll","elementIndex":0}

IMPORTANT QUESTION TYPE PATTERNS & HOW TO SOLVE:

1) MULTIPLE CHOICE / TRUE-FALSE / SINGLE SELECT:
   → Click the correct radio_label or answer_element
   → Action: {"type":"click","elementIndex":N}

2) FILL IN THE BLANK (single word):
   → Type the missing word into text_input
   → Action: {"type":"type","elementIndex":N,"value":"word"}

3) OPEN TEXT ANSWER (full sentence/paragraph):
   → Find textarea or textarea_like element
   → Type the complete answer
   → Action: {"type":"type","elementIndex":N,"value":"full sentence"}

4) CHRONOLOGICAL / SEQUENCE ORDERING:
   → Assign correct numbers (1,2,3...) to sequence_input elements
   → Actions: {"type":"click","elementIndex":N}, {"type":"type","elementIndex":N,"value":"1"}

5) PHOTO-TO-TEXT MATCHING:
   → Click text label first, then matching image container
   → Two separate click actions per pair

6) DRAG-AND-DROP CONNECT:
   → Action: {"type":"drag","fromIndex":N,"toIndex":M}

7) DROPDOWN SELECT:
   → Action: {"type":"select","elementIndex":N,"value":"option text"}

RETURN ONLY VALID JSON. No extra text before or after the JSON block.
Format:
{
  "questionType": "multiple_choice|fill_in|open_text|sequence|photo_match|connect|drag_drop|dropdown|true_false|none",
  "answer": "AIŠKUS ir KONKRETUS aprašymas KĄ daryti ir KUR (pvz. 'Pasirink B — Fotosintezė, 2-as variantas iš viršaus' arba 'Nutempk Vandenilis į 1-ą langelį kairėje'). NIEKADA nerašyk tik 'answer B'.",
  "actions": [
    {"type":"click","elementIndex":5,"reason":"Pasirinkti variantą B — Fotosintezė"},
    {"type":"type","elementIndex":10,"value":"Vilnius"}
  ]
}`;
}

// --- API WRAPPERS ---
async function askGroq(screenshotDataUrl, prompt, systemMsg) {
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + GROQ_API_KEY },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [
          { role: "system", content: systemMsg || "You are ElijasGPT V4 quiz solver. Return structured output." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: screenshotDataUrl } }
          ]}
        ],
        temperature: 0.1, max_tokens: 800
      })
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || body?.error?.code || res.statusText;
      console.warn(`Groq ${res.status}: ${reason}`);
      setStatus(`Groq klaida (${res.status}) → bandoma Mistral...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Groq:", e.message); return null; }
}

async function askMistral(screenshotDataUrl, prompt, systemMsg) {
  try {
    const res = await fetch("https://api.mistral.ai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + MISTRAL_API_KEY },
      body: JSON.stringify({
        model: "mistral-medium-latest",
        messages: [
          { role: "system", content: systemMsg || "You are ElijasGPT V4 quiz solver. Return structured output." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: screenshotDataUrl } }
          ]}
        ],
        temperature: 0.1, max_tokens: 800
      })
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || body?.error?.code || res.statusText;
      console.warn(`Mistral ${res.status}: ${reason}`);
      setStatus(`Mistral klaida (${res.status}) → bandoma Gemini...`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("Mistral:", e.message); return null; }
}

async function askGemini(screenshotDataUrl, prompt) {
  try {
    const res = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + GEMINI_API_KEY,
      { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [
            { text: prompt },
            { inlineData: { mimeType: "image/jpeg", data: screenshotDataUrl.split(",")[1] } }
          ]}],
          generationConfig: { temperature: 0.1, maxOutputTokens: 800 }
        })
      }
    );
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || res.statusText;
      console.warn(`Gemini ${res.status}: ${reason}`);
      setStatus(`Gemini klaida (${res.status})`);
      return null;
    }
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? null;
  } catch(e) { console.warn("Gemini:", e.message); return null; }
}

async function askChatGPT(screenshotDataUrl, prompt, systemMsg) {
  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + OPENAI_API_KEY },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemMsg || "You are ElijasGPT V4 quiz solver. Return structured output." },
          { role: "user", content: [
            { type: "text",      text: prompt },
            { type: "image_url", image_url: { url: screenshotDataUrl } }
          ]}
        ],
        temperature: 0.1, max_tokens: 800
      })
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      const reason = body?.error?.message || res.statusText;
      console.warn(`ChatGPT ${res.status}: ${reason}`);
      setStatus(`ChatGPT klaida (${res.status})`);
      return null;
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? null;
  } catch(e) { console.warn("ChatGPT:", e.message); return null; }
}

function parseAIJson(text) {
  if(!text) return null;
  try { return JSON.parse(text.trim()); } catch(e) {}
  const m = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if(m) { try { return JSON.parse(m[1].trim()); } catch(e) {} }
  const s=text.indexOf('{'), en=text.lastIndexOf('}');
  if(s!==-1&&en!==-1) { try { return JSON.parse(text.substring(s,en+1)); } catch(e) {} }
  return null;
}

async function askAIForActions(screenshot, elements, pageTitle) {
  const prompt = buildAutoAnswerPrompt(elements, pageTitle);
  const sc = await resizeDataUrl(screenshot);

  setStatus("Groq analizuoja...");
  const r = await askGroq(sc, prompt, "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON.");
  if(r) { const p=parseAIJson(r); if(p) return p; }

  setStatus("Mistral analizuoja...");
  const m = await askMistral(sc, prompt, "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON.");
  if(m) { const p=parseAIJson(m); if(p) return p; }

  setStatus("Gemini analizuoja...");
  const g = await askGemini(sc, prompt);
  if(g) { const p=parseAIJson(g); if(p) return p; }

  setStatus("ChatGPT analizuoja...");
  const c = await askChatGPT(sc, prompt, "You are ElijasGPT V4 quiz solver. Return ONLY valid JSON.");
  if(c) { const p=parseAIJson(c); if(p) return p; }

  return null;
}

async function askAISolve(screenshot) {
  const sc = await resizeDataUrl(screenshot);
  const sys = "You are a quiz answer bot. Output ONLY direct answers. No introduction, no explanation. Start immediately with K1:";

  setStatus("Groq analizuoja...");
  const r = await askGroq(sc, SOLVER_PROMPT, sys);
  if(r && r.trim()) return { text: r.trim(), source: "Groq" };

  setStatus("Mistral analizuoja...");
  const m = await askMistral(sc, SOLVER_PROMPT, sys);
  if(m && m.trim()) return { text: m.trim(), source: "Mistral" };

  setStatus("Gemini analizuoja...");
  const g = await askGemini(sc, SOLVER_PROMPT);
  if(g && g.trim()) return { text: g.trim(), source: "Gemini" };

  setStatus("ChatGPT analizuoja...");
  const c = await askChatGPT(sc, SOLVER_PROMPT, sys);
  if(c && c.trim()) return { text: c.trim(), source: "ChatGPT" };

  return null;
}

// --- V4 OUTPUT RENDERER ---
function renderV4FormattedAnswers(answersArray) {
  if(!output) return;
  output.innerHTML = "";

  if(!answersArray || answersArray.length === 0) {
    output.textContent = "Nera gautu rezultatu.";
    return;
  }

  answersArray.forEach(item => {
    const card = document.createElement("div");
    card.className = "q-block";

    const text = ((item.text || item) + "").trim();
    const lines = text.split("\n").filter(l => l.trim().length > 0);

    let html = "";
    lines.forEach(line => {
      const t = line.trim();

      // Section header: [Klausimas 1 — Groq], 📌, auto-answer summary
      if (/^\[/.test(t) || t.startsWith("📌")) {
        html += `<div class="q-title">${t}</div>`;

      // Direct answer: K1: B — Fotosinteze
      } else if (/^K\d+:/i.test(t)) {
        const colon = t.indexOf(":");
        const ref = t.substring(0, colon + 1);
        const ans = t.substring(colon + 1).trim();
        if (/->|nutempk|sujunk|→/i.test(ans)) {
          html += `<div class="q-row q-how"><b class="q-ref">${ref}</b> ⚡ ${ans}</div>`;
        } else {
          html += `<div class="q-row q-what"><b class="q-ref">${ref}</b> 🎯 ${ans}</div>`;
        }

      // Auto-answer bullet lines
      } else if (/^•\s*KA:/i.test(t) || t.includes("(KA)")) {
        html += `<div class="q-row q-what">🎯 <strong>${t.replace(/^•\s*/,"")}</strong></div>`;
      } else if (/^•\s*KUR:/i.test(t)) {
        html += `<div class="q-row q-where">📍 <strong>${t.replace(/^•\s*/,"")}</strong></div>`;
      } else if (/^•\s*KAIP:/i.test(t)) {
        html += `<div class="q-row q-how">⚡ <strong>${t.replace(/^•\s*/,"")}</strong></div>`;

      // Action result lines ✓/✗
      } else if (/^[✓✗]/.test(t)) {
        const ok = t.startsWith("✓");
        html += `<div class="q-row" style="color:${ok ? "#6ee7b7" : "#f87171"}">${t}</div>`;

      } else {
        html += `<div class="q-row">${t}</div>`;
      }
    });

    card.innerHTML = html;
    output.appendChild(card);
  });
}


// --- MODAL HANDLING ---
function showAlphaWarning() {
  return new Promise(resolve => {
    const modal = document.getElementById("alpha-warning-modal");
    if(!modal) { resolve(true); return; }
    modal.style.display = "flex";
    
    const continueBtn = document.getElementById("alpha-continue-btn");
    const cancelBtn = document.getElementById("alpha-cancel-btn");
    
    const cleanup = () => {
      continueBtn?.removeEventListener("click", onContinue);
      cancelBtn?.removeEventListener("click", onCancel);
      modal.style.display = "none";
    };
    
    const onContinue = () => { cleanup(); resolve(true); };
    const onCancel = () => { cleanup(); resolve(false); };
    
    continueBtn?.addEventListener("click", onContinue);
    cancelBtn?.addEventListener("click", onCancel);
  });
}

// --- AUTO-ANSWER ---
async function autoAnswer() {
  const proceed = await showAlphaWarning();
  if(!proceed) return;
  
  if(isRunning) return;
  isRunning=true; shouldStop=false;
  setButtons(true); showCountdownCard(true);
  output.textContent="Pradedamas V4 AUTO-ANSWER..."; setActionLog("");

  let totalDone=0, round=0, noQStreak=0, failStreak=0;
  const MAX=100, MAX_NO_Q=3, MAX_FAIL=3;

  while(round<MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    setCountdownDisplay("Nuskaitoma...", true);
    setStatus("Nuskaitomi puslapio elementai...");
    let pageData;
    try { pageData = await sendToPage({ type:"SCAN_PAGE" }); }
    catch(e) {
      setStatus("Skenavimas nepavyko: " + e.message);
      setCountdownDisplay("Klaida", false); failStreak++;
      if(failStreak>=MAX_FAIL) break;
      round--; await sleep(1500); continue;
    }

    const elements = pageData?.elements || [];
    setActionLog("Rasta elementų: " + elements.length);

    const screenshot = await getScreenshot();
    if(!screenshot) { setStatus("Nuotrauka nepavyko."); failStreak++; if(failStreak>=MAX_FAIL) break; round--; continue; }

    setCountdownDisplay("AI mąsto...", true);
    const aiResult = await askAIForActions(screenshot, elements, pageData.title||"");

    if(!aiResult) {
      failStreak++;
      setCountdownDisplay("AI klaida", false);
      setStatus("AI neatsakė ("+failStreak+"/"+MAX_FAIL+"). Patikrinkite internetą.");
      if(failStreak>=MAX_FAIL) { setStatus("Sustabdyta — AI neatsako."); break; }
      round--; await sleep(1500); continue;
    }
    failStreak=0;

    if(aiResult.questionType==="none" || !aiResult.actions || aiResult.actions.length===0) {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatusWarn("⚠️ Klausimų nerasta ("+noQStreak+"/"+MAX_NO_Q+"). Nustatykite klausimą ekrane.");
      await sleep(1000);
      if(noQStreak>=MAX_NO_Q) { setStatusError("❌ Baigta — daugiau klausimų nerasta."); setCountdownDisplay("Baigta!", false); break; }
      continue;
    }
    noQStreak=0;

    setCountdownDisplay("Vykdoma!", true);
    setStatus("Atsakymas: " + aiResult.answer + " [" + aiResult.questionType + "]");
    setActionLog("Vykdomi " + aiResult.actions.length + " veiksmas(-ai)...");

    let execResult;
    try { execResult = await sendToPage({ type:"EXECUTE_ACTIONS", actions:aiResult.actions }); }
    catch(e) { setStatus("Vykdymas nepavyko: "+e.message); await sleep(1500); continue; }

    const results = execResult?.results || [];
    const passed  = results.filter(r=>r.success).length;
    totalDone++;

    const log = results.map((r,i)=>(r.success?"✓":"✗")+" "+(r.msg||r.error||"veiksmas "+(i+1))).join("\n");
    
    const summaryText = `📌 K${round} [${aiResult.questionType}]\n• Atsakymas (KĄ): ${aiResult.answer}\n• Veiksmas (KAIP): Atlikta ${passed}/${results.length} veiksmų\n${log}`;
    
    const currentCards = Array.from(output.querySelectorAll(".q-block")).map(c => ({ text: c.innerText }));
    currentCards.unshift({ text: summaryText });
    renderV4FormattedAnswers(currentCards);

    setStatus("✓ K"+round+" atlikta! "+passed+"/"+results.length+" veiksmai. Viso: "+totalDone);
    setCountdownDisplay("Atlikta!", true);
    setActionLog(log.split('\n')[0]||"");
    await sleep(2000);
  }

  if(shouldStop) { setStatus("Sustabdyta. Atlikta: "+totalDone); setCountdownDisplay("Sustabdyta",false); }
  await sleep(2000);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Baigta: "+totalDone+" atsakyta.");
  isRunning=false;
}

// --- AUTO-SOLVE ---
async function autoSolvePage() {
  if(isRunning) return;
  isRunning=true; shouldStop=false;
  setButtons(true); showCountdownCard(true);
  let allAnswers=[];
  await saveAnswers(allAnswers);
  output.textContent="Pradedamas V4 AUTO-SOLVE...";
  let round=0, noQStreak=0, failStreak=0;
  const MAX=100, MAX_NO_Q=3, MAX_FAIL=4;

  while(round<MAX && !shouldStop) {
    round++;
    const ok = await runCountdown(3);
    if(!ok) break;

    const screenshot = await getScreenshot();
    if(!screenshot) { failStreak++; setStatus("Ekrano nuotrauka nepavyko."); if(failStreak>=MAX_FAIL) break; round--; continue; }

    setCountdownDisplay("Analizuojama...", true);
    const result = await askAISolve(screenshot);

    if(!result) {
      failStreak++;
      setStatus("Visos 3 API nepavyko ("+failStreak+"/"+MAX_FAIL+")");
      if(failStreak>=MAX_FAIL) break;
      round--; await sleep(1500); continue;
    }
    failStreak=0;

    const trimmed = result.text.trim();
    const blank   = trimmed==="" || trimmed.toUpperCase()==="NOQUESTIONS";

    if(!blank) {
      noQStreak=0;
      allAnswers.push({ text: `[Klausimas ${round} — ${result.source}]\n${trimmed}` });
      renderV4FormattedAnswers(allAnswers);
      await saveAnswers(allAnswers);
      setStatus("✓ Klausimas "+round+" išanalizuotas ("+result.source+")! Viso: "+allAnswers.length);
      setCountdownDisplay("Gauta!", true);
      await sleep(1500);
    } else {
      noQStreak++;
      setCountdownDisplay("Nėra klausimo", false);
      setStatusWarn("⚠️ Klausimas nerastas ("+noQStreak+"/"+MAX_NO_Q+").");
      await sleep(1000);
      if(noQStreak>=MAX_NO_Q) { setStatusError("❌ Baigta — klausimų nerasta."); setCountdownDisplay("Baigta!",false); break; }
    }
  }

  if(shouldStop) { setStatus("Sustabdyta. Išsaugota: "+allAnswers.length); setCountdownDisplay("Sustabdyta",false); }
  await sleep(2500);
  showCountdownCard(false); setButtons(false);
  setStatusSmall("Auto-solve: "+allAnswers.length+" atsakymai.");
  isRunning=false;
}

// --- ANALYZE PAGE ---
async function analyzePage() {
  const userCustom = userPromptEl.value.trim();
  const prompt = userCustom ? (userCustom + "\n\n" + SOLVER_PROMPT) : SOLVER_PROMPT;
  setStatusSmall("Analizuojama..."); output.textContent="Analizuojama...";
  const raw = await getScreenshot();
  if(!raw) { setStatusSmall("Nuotrauka nepavyko."); output.textContent="Nuotrauka nepavyko."; return; }
  const sc = await resizeDataUrl(raw);
  const sys = "You are a quiz answer bot. Output ONLY direct answers. No introduction, no explanation. Start immediately with K1:";
  let text = await askGroq(sc, prompt, sys), src="Groq";
  if(!text) { text = await askMistral(sc, prompt, sys); src="Mistral"; }
  if(!text) { text = await askGemini(sc, prompt); src="Gemini"; }
  if(!text) { text = await askChatGPT(sc, prompt, sys); src="ChatGPT"; }
  if(text) {
    renderV4FormattedAnswers([{ text: `[Analizė — ${src}]\n${text}` }]);
    setStatusSmall("Atlikta — "+src+".");
  } else { output.textContent="Visos API nepavyko."; setStatusSmall("Klaida."); }
}

// --- EVENTS ---
document.getElementById("autoAnswerBtn").addEventListener("click", autoAnswer);
document.getElementById("autoSolveBtn").addEventListener("click", autoSolvePage);
document.getElementById("stopBtn").addEventListener("click", () => { shouldStop=true; setStatus("Stabdoma..."); });
document.getElementById("analyzePage").addEventListener("click", analyzePage);
document.getElementById("capturePage").addEventListener("click", async () => {
  setStatusSmall("Daroma nuotrauka...");
  const raw = await getScreenshot();
  if(raw) {
    const s = await resizeDataUrl(raw);
    preview.src=s; preview.style.display="block";
    setStatusSmall("Nuotrauka padaryta.");
  } else {
    setStatusSmall("Nuotraukos klaida.");
  }
});
document.getElementById("clearAnswers").addEventListener("click", async () => {
  await chrome.storage.local.remove(ANSWERS_KEY);
  output.textContent="Nėra gautų rezultatų.";
  preview.style.display="none";
  preview.src="";
  setStatusSmall("Išvalyta.");
});
document.querySelectorAll(".chip").forEach(chip => {
  chip.addEventListener("click", () => { userPromptEl.value=chip.getAttribute("data-prompt"); });
});

const copyBtn = document.getElementById("copyOutputBtn");
if(copyBtn) {
  copyBtn.addEventListener("click", () => {
    const textToCopy = output.innerText || output.textContent;
    if(textToCopy) {
      navigator.clipboard.writeText(textToCopy).then(() => {
        copyBtn.textContent = "Kopijuota! ✓";
        setTimeout(() => copyBtn.textContent = "📋 Kopijuoti", 2000);
      });
    }
  });
}

// ─── MINI BAR & CONSOLE UI LOGIC ───
const fullApp = document.getElementById("full-app");
const miniBar = document.getElementById("mini-bar");
const minBtn  = document.getElementById("minimizeBtn");
const expandBtn=document.getElementById("mini-expand");
const termPanel=document.getElementById("console-panel");
const termBtn  = document.getElementById("consoleToggleBtn");

if(minBtn && fullApp && miniBar) {
  minBtn.addEventListener("click", () => {
    fullApp.style.display = "none";
    miniBar.style.display = "flex";
  });
}
if(expandBtn && fullApp && miniBar) {
  expandBtn.addEventListener("click", () => {
    miniBar.style.display = "none";
    fullApp.style.display = "flex";
  });
}
if(termBtn && termPanel) {
  termBtn.addEventListener("click", () => {
    const open = termPanel.classList.toggle("open");
    document.body.classList.toggle("console-open", open);
    termBtn.classList.toggle("active", open);
  });
}
document.getElementById("consoleClearBtn")?.addEventListener("click", () => {
  const p = document.getElementById("console-output");
  if(p) p.innerHTML = "";
});
document.getElementById("consoleCloseBtn")?.addEventListener("click", () => {
  termPanel?.classList.remove("open");
  document.body.classList.remove("console-open");
  termBtn?.classList.remove("active");
});
document.getElementById("mini-autoAnswer")?.addEventListener("click", autoAnswer);
document.getElementById("mini-autoSolve")?.addEventListener("click", autoSolvePage);
document.getElementById("mini-stop")?.addEventListener("click", () => { shouldStop=true; setStatus("Stabdoma..."); });

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  try { chrome.runtime.connect({ name: "elijasgpt-sidepanel" }); } catch(e) {}

  const box = document.getElementById("answer-box");
  if(box) {
    box.value = await loadValue();
    box.addEventListener("input", debounce(async e => { await saveValue(e.target.value); }, DEBOUNCE_DELAY));
  }
  const saved = await loadAnswers();
  if(saved.length>0) {
    renderV4FormattedAnswers(saved);
    setStatusSmall("Užkrauta "+saved.length+" išsaugotų.");
  }
});
